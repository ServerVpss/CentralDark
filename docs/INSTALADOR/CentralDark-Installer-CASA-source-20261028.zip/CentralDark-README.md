# CENTRALDARK INSTALLER v3.0

**Capsula Linux | Dual Boot | WSL opcional | Hermes CLI dentro do openKylin**

## Como abrir

### Duplo clique no EXE (recomendado — sem console)
1. Navegue ate `E:\VMs\CentralDark-Installer`
2. De duplo clique em **`CentralDark-Installer.exe`**
3. O launcher detecta se voce tem privilegio de Administrador. Se nao, oferece reiniciar elevado (UAC). Sem elevacao, consultas de disco podem falhar.
4. A janela do instalador abre diretamente, sem terminal ou console visivel

### CMD antigo (compatibilidade)
O `CentralDark-Installer.cmd` apenas encaminha para o `.exe`. A janela do CMD pode piscar ao clicar no `.cmd`; para abrir sem janela preta, use **diretamente o `CentralDark-Installer.exe`**.

### Via VS Code (para editar o fonte)
1. Abra o VS Code
2. **File > Open Folder** → selecione `E:\VMs\CentralDark-Installer`
3. Arquivos editaveis:
   - `CentralDark-Installer.ps1` — toda a GUI WinForms e logica (PowerShell 5.1)
   - `CentralDark-Installer-Launcher.cs` — launcher C# que compila para o `.exe`
4. Alteracoes no `.ps1` aparecem na proxima abertura, sem recompilar. Recompile o `.exe` apenas quando editar o `.cs`.

## Como compilar o EXE

O compilador C# ja vem no Windows (Framework 4.0). Abra um terminal e execute:

```
C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe /nologo /target:winexe /platform:anycpu /out:"CentralDark-Installer.exe" /r:System.Windows.Forms.dll "CentralDark-Installer-Launcher.cs"
```

Ou com Framework64:

```
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /nologo /target:winexe /platform:anycpu /out:"CentralDark-Installer.exe" /r:System.Windows.Forms.dll "CentralDark-Installer-Launcher.cs"
```

Execute o comando dentro da pasta `E:\VMs\CentralDark-Installer`. O binario `CentralDark-Installer.exe` sera gerado na mesma pasta.

## Estrutura do projeto

| Arquivo | Descricao |
|---------|-----------|
| `CentralDark-Installer.exe` | Executavel nativo Windows — duplo clique para abrir (sem console) |
| `CentralDark-Installer-Launcher.cs` | Fonte C# do launcher — compila para o `.exe` acima |
| `CentralDark-Installer.ps1` | Fonte PowerShell 5.1 com GUI WinForms, tema escuro, toda a logica |
| `CentralDark-Installer.cmd` | Fallback antigo — prefere o `.exe` quando presente |
| `CentralDark-README.md` | Esta documentacao |
| `CentralDark-MISSAO-OPUS.md` | Missao e especificacao do projeto |

Todos os arquivos ficam na mesma pasta. Nenhuma dependencia externa, nenhum npm, Node, Electron ou pacote adicional.

## Funcionalidades (v3.0)

### Funcionalidades de analise (read-only)

- **ANALISAR**: inventario real de discos fisicos via `Get-Disk`, `Get-Partition`, `Get-Volume` — modelo, tamanho, GPT/MBR, tipo de barramento (bus type), particoes, letras de drive, ocupacao, espaco livre NTFS e espaco nao alocado. Detecta e marca disco do sistema Windows e particoes EFI.
- **PREPARAR PLANO**: gera plano dry-run com 7 fases. Calcula espaco NTFS livre, espaco nao alocado e reducao maxima efetiva via `Get-PartitionSupportedSize` (somente leitura). Aplica margem de seguranca de 2 GiB. Detecta particao EFI existente (reutiliza) ou alerta sobre necessidade de criar nova. Aviso distinto entre espaco NTFS e espaco nao alocado com destaque visual.
- **VERIFICAR**: consulta em modo read-only ISO, discos, particoes EFI, inventario opcional do WSL e privilegio Administrador. O Hermes CLI e um componente FUTURO do openKylin, nao um programa a ser detectado no Windows. Nao executa instalacao nem procura Hermes Desktop para aprovar esta etapa.
- **SHA256**: calcula hash SHA256 da ISO selecionada para validacao de integridade (cursor de espera durante calculo).
- **EXPORTAR RELATORIO**: salva conteudo da area de saida em `.txt` com cabecalho (data, disco, ISO, admin, preservacao).

### Funcionalidades de interface

- **Indicador de fase**: faixa de 6 indicadores coloridos (1 ANALISAR, 2 PREPARAR, 3 VERIFICAR, 6 INSTALAR, 7 DUAL BOOT, 8 HERMES CLI) com status por cor — cinza (pendente), ciano (em curso), verde (concluido), amarelo (guiado/pendente manual).
- **Indicador Admin**: mostra se executa como Administrador (verde) ou nao (amarelo) no canto superior.
- **Aviso de disco sistema**: alerta vermelho "DISCO SISTEMA!" quando o disco selecionado contem a particao Windows.
- **Botao PREPARAR PLANO desabilitado** ate selecionar um disco (visual de botao inativo).
- **Tooltips**: todos os botoes mostram descricao ao passar o mouse.
- **Letras de drive no combo**: o seletor de disco mostra as letras (ex: `[K:]`) para facilitar identificacao.
- **Hash da ISO**: botao 4 SHA256 ISO na linha de testes seguros, resultado exibido em fonte mono abaixo.
- **Tema escuro CentralDark**: paleta escura com acentos ciano, verde, amarelo e vermelho.

### Fases guiadas (nao executam acoes destrutivas)

Os botoes 6 INSTALAR (GUIADO), 7 DUAL BOOT (GUIADO) e 8 HERMES CLI (GUIADO) exibem orientacao detalhada com:
- Checklist de pre-requisitos (formato checkbox)
- Passos numerados para execucao manual
- Status PENDENTE/GUIADO com indicador visual
- Dicas de troubleshooting (ex: GRUB nao detecta Windows)

### Honestidade sobre WSL

A orientacao do passo 8 descreve Hermes CLI no openKylin e, em separado, as limitacoes opcionais do WSL:
- WSL2 opera com kernel proprio em VM Hyper-V — NAO e o mesmo sistema Linux do disco
- `wsl --mount` permite acesso a dados da particao ext4, mas nao e equivalente a boot nativo
- Importar .tar cria copia independente, nao acesso ao mesmo sistema
- NAO sera criada segunda capsula WSL sem validacao real

## Fases futuras (requerem aprovacao do CHEFE)

| Fase | Descricao | Status |
|------|-----------|--------|
| 1 | Isolar/preservar NTFS atual | PENDENTE |
| 2 | Liberar espaco — redimensionar NTFS, criar particoes | PENDENTE |
| 3 | Instalar openKylin via ISO existente | PENDENTE |
| 4 | Configurar dual boot (GRUB + Windows Boot Manager) | PENDENTE |
| 5 | WSL opcional — avaliar acesso a dados, sem confundir com sistema Linux nativo | OPCIONAL / PENDENTE |
| 6 | Instalar e validar Hermes CLI dentro do openKylin (apos Linux instalado e inicializado) | PENDENTE |
| 7 | Validacao final | PENDENTE |
| 8 | Reconciliar dados e receitas da CentralDark no openKylin apos o primeiro boot | PENDENTE / PLANO DRY-RUN |

Cada fase futura sera implementada com confirmacao especifica. Nenhuma acao destrutiva existe no codigo atual.

### CentralDark local primeiro: Casa, VPS e recuperacao de dados (28/10/2026)

**Owner unico:** este `E:\VMs\CentralDark-Installer` prepara o disco fisico/openKylin na Casa. O owner `K:\install.sh` prepara os servicos da CentralDark dentro de um Linux ja instalado. Nao sao dois produtos concorrentes; sao etapas diferentes. O instalador de disco NAO esta pronto para formatar/reduzir a particao automaticamente.

**CASA e VPS sao instancias locais em seus respectivos computadores.** Exposicao `private/lan/vpn/public` e uma dimensao INDEPENDENTE do perfil `casa/vps`. VPS nao implica automaticamente publicar portas na Internet. Configuracao de exposicao exige validacao propria; manter PRIVADO como estado inicial.

**K:** e letra de unidade Windows, nao raiz Linux. Apos dual boot, o Linux localiza a particao NTFS preservada por UUID/label; `CENTRALDARK_ROOT` e a raiz do checkout/replay do Linux, separada de `/` (sistema) e `/root` (home do administrador). O Installer deve detectar um caminho validado em vez de assumir `/root/CentralDark` ou `/opt/centraldark`. O owner Linux `K:\install.sh` ainda possui default legado fixo `/root/CentralDark`; portabilidade fim a fim ainda nao passou.

**Fluxo pretendido e nao realizado:**
```text
ANALISAR K: / GPT / EFI / ISO (READONLY)
-> PLANO shrink NTFS / espaco Linux (READONLY)
-> BACKUP EXTERNO RESTAURAVEL + hash + inventario (REQUIRED)
-> APROVACAO ESPECIFICA para qualquer alteracao fisica
-> INSTALAR openKylin / dual boot (PENDENTE)
-> BOOT LINUX e descobrir UUID/label dos volumes (PENDENTE)
-> MONTAR NTFS preservado inicialmente somente leitura (PENDENTE)
-> RECONCILIAR dados allowlisted, Git/Skill-Mae/receitas e bindings (PENDENTE)
-> TESTAR integridade, efeitos, rollback, recibos (PENDENTE)
-> EXPANDIR ESPACO somente se houver delta real medido e autorizacao (PENDENTE)
```

**Importante:** liberar espaco do NTFS por shrink e fazer ext4 NAO sao sinonimos de reconciliar os dados. Backup dentro do proprio K: nao e copia externa. A etapa de restauracao/reconciliacao e de Linux-pos-boot e deve ser executada por owner existente, nao pelo Windows a partir de caminho presumido. `DISK_PLAN_PASS != DATA_PRESERVATION_PROVED != INSTALLED != POST_BOOT_RECONCILIATION_PASS`.

**STATUS REAL:** analise e plano = software funcional; prova de backup externo, shrink, boot, restauracao e expansao = `PENDENTE/UNKNOWN`. O plano da fase 8 foi incorporado ao gerador `Build-Plan` do mesmo `CentralDark-Installer.ps1`, sem alterar disco, particoes, UEFI ou VM.

## Detalhes tecnicos

- **PowerShell 5.1 + WinForms**: GUI nativa do Windows sem dependencias
- **Launcher C# (.NET 4.0)**: compilado como `/target:winexe` — sem subsistema console; PowerShell executa com `CreateNoWindow=true` e `WindowStyle=Hidden`
- **Deteccao de Admin (C#)**: o launcher oferece reiniciar com elevacao UAC se nao for Administrador; o PS1 mostra indicador visual do status
- **Assembly info**: o `.exe` carrega versao 3.0.0.0, titulo e descricao visiveis em Propriedades do Windows
- **WSL sem janela**: `wsl.exe` usa `System.Diagnostics.Process` com `CreateNoWindow`, saidas assincronas em memoria e limite de 10 segundos
- **SHA256**: calculo nativo via `System.Security.Cryptography.SHA256` com streams e cleanup deterministico
- **Tema escuro**: paleta CentralDark com 4 cores de acento (ciano, vermelho, verde, amarelo)
- **Mutex de instancia unica**: o `.exe` impede abertura duplicada
- **Sem escrita fora da pasta**: relatorios e logs de erro ficam em `E:\VMs\CentralDark-Installer`
- **Sem comandos destrutivos**: nenhum comando que altera disco, boot, WSL ou sistema

## Novidades da v3.0

| Melhoria | Descricao |
|----------|-----------|
| Indicador de fase | Faixa visual com 6 fases coloridas por status |
| Deteccao Admin | Indicador visual + oferta de elevacao UAC no launcher |
| SHA256 da ISO | Botao para calcular hash de integridade |
| Deteccao EFI | Localiza particao EFI existente no plano e na verificacao |
| Aviso disco sistema | Alerta vermelho ao selecionar disco com Windows |
| NTFS vs nao alocado | Distincao clara com destaque visual no plano |
| Margem de seguranca | 2 GiB reservados no calculo de shrink NTFS |
| Letras no combo | Seletor de disco mostra letras de drive |
| Tooltips | Todos os botoes com descricao ao hover |
| Bus type | Inventario mostra tipo de barramento do disco |
| wsl --mount check | Consulta informativa; falta de confirmacao nao bloqueia Hermes CLI no Linux |
| WSL honestidade | Limitacoes tecnicas documentadas explicitamente |
| Checklist guiado | Fases manuais com formato de checklist e troubleshooting |
| Assembly info C# | Versao e metadados visiveis nas propriedades do .exe |
| Botao prerequisito | PREPARAR PLANO desabilitado sem disco selecionado |


## Revisao de robustez (26/10/2026 — mesmo projeto)

- O plano permanece **100% dry-run**: nao executa shrink, cria EFI, instala Linux, modifica boot ou inicia WSL. O botao INSTALAR LINUX e os botoes DUAL BOOT/WSL continuam **GUIADOS**, nao concluidos.
- Antes de gerar plano, o disco selecionado e revalidado contra a lista atual. Falhas ao consultar disco, EFI ou identificacao do Windows deixam de ser tratadas como ausencia segura; mostram erro e impedem conclusao enganosa.
- `LargestFreeExtent` representa **o maior trecho continuo nao alocado**, nao a soma de todos os espacos nao alocados. Espaco livre **dentro do NTFS** nao e area nao alocada.
- O valor estimado para raiz Linux agora deduz a margem de 2 GiB **e** reserva ate 512 MiB para uma possivel ESP nova. Como a EFI pode estar em outro disco, sua destinacao exige verificacao humana de firmware/layout. Se os valores medidos mudarem, o planejamento deve ser refeito.
- O SHA256 de ISO foi alterado para leitura em blocos temporizados no loop WinForms, exibindo progresso sem congelar toda a janela. Hash SHA256 calculado **nao comprova autenticidade** sem comparar com checksum oficial confiavel. A ISO original nao e escrita pelo app.
- A consulta de ajuda `wsl --help` agora drena os dois pipes assincronamente e trata timeout; em testes de desenvolvimento **nao foi iniciada nenhuma instancia WSL/VM**.
- A GUI informa erros de consulta em vez de marcar uma operacao nao comprovada como sucesso. O launcher nativo so anuncia log de erro como gravado apos confirmar escrita.
- O maior limite do produto continua sendo fisico: backup, autorizacao, particionamento, instalacao openKylin e validacao dual boot/WSL **nao foram feitos**. Um dry-run aprovado nao certifica que uma instalacao sera segura.
- Prova de codigo e build deve ser registrada no **cartao existente** `t_87d162cb`; nao abrir outro Kanban ou workspace.


## Ordem numerada da interface (26/10/2026)

A janela organiza os controles em ordem de uso, sem misturar os testes com etapas de instalacao:

1. **ANALISAR** — inventario dos discos, somente leitura.
2. **PREPARAR PLANO** — calcular layout dry-run, sem redimensionar particoes.
3. **VERIFICAR** — conferir ISO, EFI e discos, com inventario WSL opcional; o Hermes CLI sera verificado posteriormente dentro do openKylin.
4. **SHA256 ISO** — calcular a impressao digital em leitura; conferir separadamente contra fonte oficial para autenticar.
5. **EXPORTAR RELATORIO** — salvar o resultado na mesma pasta do projeto.
6. **INSTALAR (GUIADO)** — apenas checklist para aprovacao futura; **nao instala Linux**.
7. **DUAL BOOT (GUIADO)** — apenas orientacao; **nao altera EFI, BCD, bootloader ou GRUB**.
8. **HERMES CLI (GUIADO)** — orientacao para instalacao posterior dentro do openKylin; **nao instala Hermes nem altera WSL**.

Os indicadores da faixa usam a mesma ordem nas fases correspondentes (1, 2, 3, 6, 7, 8). Os passos 4 e 5 sao ferramentas complementares, nao fases de implantacao, por isso nao aparecem na faixa de status. Para ver a interface atualizada, feche e abra novamente o EXE: ele carrega o PS1 da mesma pasta a cada abertura, sem precisar recompilar o launcher C#.

## Recibo guiado — passo 6 (28/10/2026)

Este recibo e somente leitura. Ele **nao** reduziu particoes, nao formatou, nao instalou Linux, nao alterou EFI/BCD/GRUB e nao reiniciou a Casa.

- `PASSO_2_PLAN=PASS`: o plano preserva os dados NTFS de `K:`; primeiro exige backup verificavel e `chkdsk /scan`, depois — somente com aprovacao especifica — pode reduzir o NTFS. Medicao atual: 29.62 GiB usados, 417.50 GiB livres no NTFS, 0.000816 GiB nao alocados, shrink maximo consultado de 395.42 GiB, margem de 2 GiB e raiz Linux estimada de ate 393.42 GiB; NTFS minimo consultado de 51.70 GiB. O layout previsto e reutilizar a EFI existente, criar ext4 no espaco que vier a ser liberado e usar swapfile dentro do Linux. O plano nao cria particoes.
- `K_PRESERVATION=PASS`: `K:` e o volume NTFS `CENTRALDARK-OS-CASA-OBSIDIAN` no Kingston (Disco 1, GPT), com 480.09 GB e 448.28 GB livres na observacao. A particao de dados ocupa o disco; o espaco livre pertence ao NTFS e nao e espaco nao alocado. `fsutil dirty query K:` retornou limpo.
- `BACKUP=BLOCKED`: nao existe recibo de backup externo verificavel anexado ao owner nem ao relatorio auditado. Um backup valido precisa de destino externo identificado, data, tamanho/manifesto e restauracao ou leitura de amostra comprovada antes de qualquer operacao fisica.
- `ISO_SOURCE=PASS`: a fonte oficial do openKylin lista exatamente `openKylin-Desktop-V3.0-20260905-x86_64.iso` com 8,089,612,288 bytes. O SHA-256 local registrado e `98b37e282300c4b8efc7dc76f307cd856cc8b4ae2a5b98c241e0cd20424b626d`.
- `ISO_VERIFIED=BLOCKED`: o checksum oficial publicado acessivel e MD5, enquanto este recibo auditado contem SHA-256 local; hashes de algoritmos distintos nao podem ser comparados. Registrar e comparar o MD5 local com a pagina oficial antes de criar a midia USB.
- `DISK_LAYOUT=PASS`: firmware UEFI; a ESP do Windows e Disco 2, particao 1, 100 MB. O Kingston (Disco 1) nao e disco de boot nem de sistema e possui apenas MSR de 16 MB e `K:`. Nenhuma entrada de boot foi alterada.
- `STEP_6_GUIDED=PASS`: o passo 6 permanece checklist manual: plano revisado, backup verificado, espaco fisicamente liberado, USB criado a partir de ISO autenticada e boot USB autorizado. So entao a instalacao e feita manualmente na ext4 preparada e o primeiro boot Linux e validado.
- `INSTALL_READY=BLOCKED`: backup verificavel, espaco nao alocado, USB autenticado e autorizacao de boot ainda nao foram comprovados. Isto e o bloqueio correto; nao e falha do instalador.

**NEXT_CURSOR:** apresentar um backup externo restauravel de `K:` e seu recibo; depois refazer o preflight, comparar o MD5 local com a fonte oficial e somente entao submeter ao CHEFE o plano do passo 2 para aprovacao fisica separada.

## Mapa completo de telas e receita de operacao (28/10/2026)

**Owner da tela:** `CentralDark-Installer.ps1`, funcao `Show-MainWindow`. A janela e unica (`960 x 800`), WinForms, sem telas paralelas. O launcher C# aplica instancia unica; uma segunda abertura mostra somente o aviso `O CentralDark Installer ja esta em execucao.`

### Topologia fisica comprovada — Windows Identificar

O procedimento operacional unico e nativo: **Configuracoes > Sistema > Tela > Identificar**. Ele exibiu os numeros fisicos em cada painel e confirmou: `3 = esquerda`, `2 = centro superior`, `4 = centro inferior`, `1 = direita`. A leitura Windows confirmou identidade, conexao e serial abaixo. Nenhum arranjo, resolucao ou configuracao foi alterado.

| Display Windows | Monitor | Conexao | Serial | Evidencia |
|---|---|---|---|---|
| 1 | AOC 24G2W1G4 | DisplayPort | `ATNMBXA002919` | Windows Identify + `WmiMonitorID` |
| 2 | AOC 24G2W1G5 | DisplayPort | `ATOM8XA000468` | Windows Identify + `WmiMonitorID` |
| 3 | AOC 24G2W1G4 | HDMI | `ATNM4XA002193` | Windows Identify + `WmiMonitorID` |
| 4 | DELL S2421HN | HDMI | `4JD4DQ3` | Windows Identify + `WmiMonitorID` |

**Receita Windows (somente observacao):** abrir `Configuracoes` → `Sistema` → `Tela` → **Identificar**. Conferir os numerais grandes em cada monitor e fechar. Nao arrastar o diagrama, nao abrir seletor de resolucao, nao alterar modo de projecao e nao aplicar configuracao; o objetivo e apenas localizar com seguranca a tela onde o Installer estiver aberto.

### Tela principal

1. **Cabecalho** — marca CENTRALDARK INSTALLER, versao e indicador `Admin: SIM|NAO`.
2. **Painel de alvo** — combo `Disco fisico`, botao **Atualizar**, ISO Linux e botao `...`; ao selecionar disco de sistema o aviso e `DISCO SISTEMA!`.
3. **Protecao** — `Preservar arquivos existentes` inicia marcado. O usuario deve manter marcado para o fluxo de preservacao.
4. **Faixa operacional** — passos 1 a 5 sao leitura/planejamento; 6 a 8 sao visualmente amarelos e somente guiados.
5. **Log e status** — toda acao substitui ou acrescenta evidencia no painel read-only e atualiza a barra inferior.

### Acoes, efeito e limite

| Controle | Efeito observado/esperado | Limite de seguranca |
|---|---|---|
| **Atualizar** | Recarrega a lista real via `Get-Disk`; limpa selecao anterior. | Nenhuma escrita em disco. |
| **1 ANALISAR** | Inventaria disco, particoes e volumes; muda a fase para concluida, guiada ou pendente conforme a leitura. | Somente leitura. |
| **2 PREPARAR PLANO** | Exige disco selecionado; calcula o shrink possivel, margem e layout dry-run. | Nao reduz nem cria particao. |
| **3 VERIFICAR** | Confere privilegio, ISO, discos, EFI e WSL opcional; classifica PASS, ALERTA ou FALHA. | Somente leitura; alerta nao vira PASS. |
| **4 SHA256 ISO** | Le a ISO em blocos com progresso sem travar a tela e exibe SHA-256. | Integridade local; autenticidade ainda exige checksum oficial correspondente. |
| **5 EXPORTAR RELATORIO** | Salva a evidencia exibida no diretorio de dados do Installer. | Nao toca em disco de destino nem boot. |
| **6 INSTALAR (GUIADO)** | Exibe checklist manual: plano, backup, espaco liberado, USB e boot UEFI. | Nao instala Linux. |
| **7 DUAL BOOT (GUIADO)** | Exibe receita posterior de EFI/GRUB e teste de menu. | Nao altera EFI, BCD ou GRUB. |
| **8 HERMES CLI (GUIADO)** | Explica a instalacao posterior da CLI dentro do openKylin e os limites do WSL. | Nao instala Hermes nem cria distro WSL. |
| **FECHAR** | Fecha somente a janela. | Nao altera configuracao ou dados. |

### Receita operacional salva

1. Abrir `CentralDark-Installer.exe` como Administrador; se surgir aviso de instancia em execucao, usar a janela ja aberta.
2. Clicar **Atualizar**, selecionar conscientemente o disco alvo e confirmar que ele nao esta marcado como `DISCO SISTEMA!`.
3. Confirmar ISO, manter `Preservar arquivos existentes` marcado e executar, nesta ordem, **1 ANALISAR**, **2 PREPARAR PLANO**, **3 VERIFICAR** e **4 SHA256 ISO**.
4. Conferir o resultado da ISO contra checksum oficial do mesmo artefato e usar **5 EXPORTAR RELATORIO** para registrar a sessao.
5. Tratar os passos 6, 7 e 8 como instrucoes; eles permanecem pendentes ate que os pre-requisitos fisicos sejam provados e o CHEFE autorize a operacao correspondente.

### Recibo de observabilidade

- `UI_OWNER=CentralDark-Installer.ps1:Show-MainWindow`.
- `RUNTIME=PASS`: a janela principal esta ativa pelo launcher de instancia unica; VS Code esta aberto no mesmo owner.
- `VISUAL_AUTOMATION=LIMITED`: nesta sessao, a janela WinForms e hospedada por PowerShell elevado em outro monitor e o controlador visual nao consegue anexar seus controles. Nenhum clique foi simulado ou declarado como executado.
- `SELF_IMPROVEMENT_BOUNDARY=PASS`: o aprendizado foi salvo no owner existente como mapa e receita; nenhuma skill, runtime ou instalador paralelo foi criado.
