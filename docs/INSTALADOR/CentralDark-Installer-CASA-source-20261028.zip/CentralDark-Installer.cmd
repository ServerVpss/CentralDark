@echo off
if exist "%~dp0CentralDark-Installer.exe" (
    start "" "%~dp0CentralDark-Installer.exe"
    exit /b 0
)
echo [CENTRALDARK] Executavel nao encontrado nesta pasta.
echo Abra o projeto no VS Code e compile CentralDark-Installer-Launcher.cs.
exit /b 2
