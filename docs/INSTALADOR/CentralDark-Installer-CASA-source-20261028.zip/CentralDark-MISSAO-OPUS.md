# CENTRALDARK INSTALLER — FINALIZACAO
TASK_ID=t_87d162cb
ID_MAE=t_911e17ff
CLASSIFICACAO=ARCHITECTURAL
BREATH=1 Concentração Total -> 9 Flor -> 5 Chamas -> 3 Lua
OWNER_UNICO=E:\VMs\CentralDark-Installer
MODELO=Claude Code Opus 4.6

ORDEM DO CHEFE
Melhorar e terminar o CENTRALDARK INSTALLER, a partir do código existente. Trabalhar somente em E:\VMs\CentralDark-Installer. Fonte aberta pelo VS Code. Executável .exe Windows sem console. Não criar pasta ou projeto paralelo. Não criar segunda missão Kanban.

RECURSOS EXISTENTES
CentralDark-Installer.ps1 (PowerShell 5.1 WinForms), CentralDark-Installer-Launcher.cs (C# nativo Windows), CentralDark-Installer.exe (GUI), CentralDark-Installer.cmd, CentralDark-README.md. ISO openKylin no caminho E:\VMs\openKylin-Desktop-V3.0-20260905-x86_64.iso. Disco físico Kingston K: GPT ~447 GiB, ~51 GiB usados e ~395 GiB livres dentro do NTFS, NAO espaço não alocado. Antes de operar, medir valores atuais com Get-Disk/Get-Partition/Get-Volume. O antigo ext4.vhdx do WSL openKylin foi removido. Nao restaurar. Ubuntu e Docker WSL não são parte desta missão.

RESULTADO DE SOFTWARE ESPERADO
1. Revisar e corrigir o código atual. Melhorar robustez, erros, eventos, tempo limite, travamentos da UI e segurança de nomes de dispositivo. Sem falsos sucessos. Preservar marca CENTRALDARK.
2. GUI profissional de janela única sem vazamento de PowerShell/cmd, com descoberta real de disco físico e selecao explícita, partições e tamanho livre/usado, ISO e hash, botões com estados claros, painel de logs e status. Executável nativo Windows deve seguir editável no VS Code.
3. Plano dinâmico e verificável com preservação dos arquivos existentes, layout do Linux usando aproximadamente todos os 395 GiB atualmente livres quando selecionado K: (sem padrão artificial de 60/80 GiB), precondições NTFS/EFI, aviso distinto para espaço livre do NTFS e espaço NÃO ALOCADO, rastros de verificação.
4. Motor reutilizável com fases ANALISAR, PREPARAR, INSTALAR LINUX, DUAL BOOT, WSL + HERMES, VERIFICAR. Implementar tanta lógica e automação REAL quanto possível em código; onde instalação física exige reinício ou confirmação/manual, distinguir GUIADO/PENDENTE e nunca mentir que acabou. Não criar segunda cápsula WSL. Verificar os limites reais de acesso WSL ao MESMO Linux físico (não tratar importacao de vhdx como sistema fisico igual). Falar de limite tecnicamente honesto quando não puder comprovar.
5. Operações de preparação e instalação em código sempre protegidas por confirmação explícita na UI, verificação de destino, preservação, inventário e salvaguardas; desenvolvimento/testes desta rodada não executar nenhum passo que altera disco/boot/WSL. O CHEFE acionará instalação posteriormente.
6. Manter todo arquivo fonte, teste, relatório do projeto e novo artefato na pasta única E:\VMs\CentralDark-Installer. Evitar adicionar arquivos desnecessários; não instalar Node/Electron/npm ou SDK paralelo. Compiler nativo disponível C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe.
7. Atualizar README, rodar testes de parser seguros e build do .exe, fazer smoke GUI somente se não alterar sistema. Recibo objetivo com funcionalidades verificadas, pendências e NEXT_CURSOR.

NAO FAZER DURANTE ESTA MISSAO
Nao redimensionar partição, formatar, tocar no K:, Windows boot/EFI/BCD/GRUB, registrar ou iniciar WSL/VM, reiniciar Casa, instalar openKylin ou modificar ISO; somente criar e validar SOFTWARE do instalador. Não criar outro Kanban, gateway ou pasta irmã.

DONE_SOFTWARE exige arquivo entregue, parser ok, compilaçao C# exit 0 e smoke sem console. DONE_INSTALACAO exige instalacao real autorizada e validada em outra etapa.
## ATUALIZACAO DA ORDEM DO CHEFE — 26/10/2026

**Hermes e uma CLI que sera instalada DENTRO do openKylin DEPOIS que a ISO tiver sido usada para instalar e iniciar o Linux.** Nao exigir Hermes Desktop do Windows e nao marcar falta de Hermes no Windows como erro do instalador. A verificacao do Windows pode registrar apenas `HERMES_CLI_LINUX=PENDENTE_POS_INSTALACAO`. WSL e uma capacidade opcional e separada; WSL nao e necessario para instalar Hermes CLI no Linux nativo. Fase Hermes fica GUIADA/PENDENTE; esta missao desenvolve e testa somente o software Windows, sem executar instalacao openKylin, Hermes, particoes, EFI, boot ou WSL. Preservar mesmo workspace e mesmo card `t_87d162cb`.
