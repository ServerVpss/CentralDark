﻿#Requires -Version 5.1
<#
    CENTRALDARK INSTALLER v3.0
    Capsula Linux | Dual Boot | WSL opcional | Hermes CLI no openKylin
    PowerShell 5.1 WinForms - analise, planejamento e fases guiadas
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# -- Cores do tema escuro ----------------------------------------------
$script:BgDark       = [System.Drawing.Color]::FromArgb(18, 18, 24)
$script:BgPanel      = [System.Drawing.Color]::FromArgb(28, 28, 38)
$script:BgInput      = [System.Drawing.Color]::FromArgb(36, 36, 48)
$script:FgLight      = [System.Drawing.Color]::FromArgb(220, 220, 230)
$script:FgDim        = [System.Drawing.Color]::FromArgb(140, 140, 160)
$script:AccentCyan   = [System.Drawing.Color]::FromArgb(0, 200, 220)
$script:AccentRed    = [System.Drawing.Color]::FromArgb(220, 60, 60)
$script:AccentGreen  = [System.Drawing.Color]::FromArgb(60, 200, 80)
$script:AccentYellow = [System.Drawing.Color]::FromArgb(220, 200, 60)
$script:BtnBg        = [System.Drawing.Color]::FromArgb(44, 44, 60)
$script:BtnHover     = [System.Drawing.Color]::FromArgb(60, 60, 80)
$script:BtnDisabled  = [System.Drawing.Color]::FromArgb(32, 32, 42)

$script:InstallerDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$script:IsoDefault   = 'E:\VMs\openKylin-Desktop-V3.0-20260905-x86_64.iso'
$script:DataDir      = $null

$script:PhaseNames  = @('ANALISAR','PREPARAR','VERIFICAR','INSTALAR','DUAL BOOT','HERMES CLI')
$script:PhaseStatus = @{}
foreach ($p in $script:PhaseNames) { $script:PhaseStatus[$p] = 'PENDENTE' }

# -- Helpers -----------------------------------------------------------
function New-DarkButton {
    param([string]$Text, [int]$X, [int]$Y, [int]$W = 160, [int]$H = 36)
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text      = $Text
    $btn.Location  = New-Object System.Drawing.Point($X, $Y)
    $btn.Size      = New-Object System.Drawing.Size($W, $H)
    $btn.FlatStyle = 'Flat'
    $btn.FlatAppearance.BorderColor = $script:AccentCyan
    $btn.FlatAppearance.BorderSize  = 1
    $btn.BackColor = $script:BtnBg
    $btn.ForeColor = $script:FgLight
    $btn.Font      = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
    $btn.Cursor    = [System.Windows.Forms.Cursors]::Hand
    $btn.Add_MouseEnter({ if ($this.Enabled) { $this.BackColor = $script:BtnHover } })
    $btn.Add_MouseLeave({ if ($this.Enabled) { $this.BackColor = $script:BtnBg } })
    return $btn
}

function Write-Status {
    param([string]$Msg, [string]$Level = 'INFO')
    $ts = Get-Date -Format 'HH:mm:ss'
    $prefix = switch ($Level) {
        'OK'    { '[OK]   ' }
        'WARN'  { '[WARN] ' }
        'ERROR' { '[ERRO] ' }
        'PHASE' { '[FASE] ' }
        default { '[INFO] ' }
    }
    $script:txtOutput.AppendText("$ts $prefix $Msg`r`n")
    $script:txtOutput.ScrollToCaret()
}

function Get-InstallerDataDir {
    if ($script:DataDir -and (Test-Path -LiteralPath $script:DataDir -PathType Container)) {
        return $script:DataDir
    }
    $candidates = @(
        (Join-Path $env:ProgramData 'CentralDark\Installer'),
        (Join-Path $env:LOCALAPPDATA 'CentralDark\Installer'),
        (Join-Path $script:InstallerDir 'data')
    )
    foreach ($candidate in $candidates) {
        try {
            New-Item -ItemType Directory -Path $candidate -Force -ErrorAction Stop | Out-Null
            $script:DataDir = $candidate
            return $script:DataDir
        } catch { }
    }
    throw 'Nao foi possivel criar uma pasta segura para relatorios e estado.'
}

function Test-IsAdmin {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-PreflightResult {
    param([string]$IsoPath)
    $result = [ordered]@{ Admin = (Test-IsAdmin); Iso = $false; IsoSize = 0; Messages = @() }
    if ([string]::IsNullOrWhiteSpace($IsoPath)) {
        $result.Messages += '[ERRO] Nenhuma ISO Linux foi selecionada.'
        return [pscustomobject]$result
    }
    try {
        $item = Get-Item -LiteralPath $IsoPath -ErrorAction Stop
        if (-not $item.PSIsContainer -and $item.Length -gt 0) {
            $result.Iso = $true
            $result.IsoSize = $item.Length
        } else {
            $result.Messages += '[ERRO] O caminho informado nao e um arquivo ISO valido.'
        }
    } catch {
        $result.Messages += "[ERRO] ISO inacessivel: $($_.Exception.Message)"
    }
    if (-not $result.Admin) {
        $result.Messages += '[WARN] Sem Administrador: consultas de disco podem ficar incompletas.'
    }
    return [pscustomobject]$result
}

function Get-IsoSha256 {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    try {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            $stream = [System.IO.File]::OpenRead($Path)
            try {
                $hashBytes = $sha.ComputeHash($stream)
                return [BitConverter]::ToString($hashBytes).Replace('-','').ToLower()
            } finally {
                $stream.Close()
                $stream.Dispose()
            }
        } finally {
            $sha.Dispose()
        }
    } catch {
        return "ERRO: $($_.Exception.Message)"
    }
}

function Test-IsSystemDisk {
    param([int]$DiskNumber)
    try {
        $parts = Get-Partition -DiskNumber $DiskNumber -ErrorAction Stop
        foreach ($p in $parts) {
            if ($p.DriveLetter -eq 'C') { return $true }
            if ($p.IsSystem -or $p.IsBoot) { return $true }
        }
    } catch {
        throw "Nao foi possivel verificar se o disco $DiskNumber contem o Windows: $($_.Exception.Message)"
    }
    return $false
}

function Get-EfiPartitions {
    param([int]$DiskNumber)
    $results = @()
    try {
        $parts = Get-Partition -DiskNumber $DiskNumber -ErrorAction Stop
        foreach ($p in $parts) {
            if ($p.GptType -eq '{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}' -or $p.Type -eq 'System') {
                $results += [pscustomobject]@{
                    PartitionNumber = $p.PartitionNumber
                    SizeMB          = [math]::Round($p.Size / 1MB, 0)
                    DriveLetter     = $p.DriveLetter
                }
            }
        }
    } catch {
        throw "Nao foi possivel consultar as particoes EFI do disco $($DiskNumber): $($_.Exception.Message)"
    }
    return $results
}

# -- Discovery real de discos ------------------------------------------
function Get-DiskInventory {
    $results = @()
    try {
        $disks = Get-Disk -ErrorAction Stop
        foreach ($d in $disks) {
            $sizeGB  = [math]::Round($d.Size / 1GB, 2)
            $style   = $d.PartitionStyle
            $model   = if ($d.FriendlyName) { $d.FriendlyName } else { '(sem modelo)' }
            $busType = if ($d.BusType) { $d.BusType } else { '?' }
            $unalloc = ''
            if ($d.LargestFreeExtent -and $d.LargestFreeExtent -gt 0) {
                $unalloc = " | Nao alocado: $([math]::Round($d.LargestFreeExtent / 1GB, 2)) GiB"
            }
            $isSystem = Test-IsSystemDisk -DiskNumber $d.Number
            $sysTag   = if ($isSystem) { ' [SISTEMA WINDOWS]' } else { '' }

            $partitions = @()
            try {
                $parts = Get-Partition -DiskNumber $d.Number -ErrorAction Stop
                foreach ($p in $parts) {
                    $pSizeGB = [math]::Round($p.Size / 1GB, 2)
                    $letter  = if ($p.DriveLetter) { "$($p.DriveLetter):" } else { '--' }
                    $volInfo = ''
                    if ($p.DriveLetter) {
                        try {
                            $v = Get-Volume -DriveLetter $p.DriveLetter -ErrorAction Stop
                            $usedGB = [math]::Round(($v.Size - $v.SizeRemaining) / 1GB, 2)
                            $freeGB = [math]::Round($v.SizeRemaining / 1GB, 2)
                            $label  = if ($v.FileSystemLabel) { $v.FileSystemLabel } else { '(sem label)' }
                            $volInfo = " [$($v.FileSystem) `"$label`" Usado: ${usedGB} GiB | Livre NTFS: ${freeGB} GiB]"
                        } catch {
                            $volInfo = " [VOLUME NAO CONSULTADO: $($_.Exception.Message)]"
                        }
                    }
                    $typeTag = $p.Type
                    if ($p.GptType -eq '{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}' -or $p.Type -eq 'System') {
                        $typeTag = 'EFI System'
                    }
                    $partitions += "    Part $($p.PartitionNumber): $letter  ${pSizeGB} GiB  Tipo: $typeTag$volInfo"
                }
            } catch {
                $partitions += "    (erro ao ler particoes: $($_.Exception.Message))"
            }
            $entry = "Disco $($d.Number): $model | ${sizeGB} GiB | $style | Bus: $busType$unalloc$sysTag"
            $results += $entry
            $results += $partitions
            $results += ''
        }
    } catch {
        throw "Falha ao enumerar discos: $($_.Exception.Message)"
    }
    return $results
}

function Get-DiskListForCombo {
    $items = @()
    try {
        $disks = Get-Disk -ErrorAction Stop
        foreach ($d in $disks) {
            $sizeGB = [math]::Round($d.Size / 1GB, 2)
            $model  = if ($d.FriendlyName) { $d.FriendlyName } else { '?' }
            $letters = @()
            try {
                foreach ($p in (Get-Partition -DiskNumber $d.Number -ErrorAction Stop)) {
                    if ($p.DriveLetter) { $letters += "$($p.DriveLetter):" }
                }
            } catch {
                throw "Particoes do disco $($d.Number) nao verificadas: $($_.Exception.Message)"
            }
            $letterStr = if ($letters.Count -gt 0) { " [$($letters -join ', ')]" } else { '' }
            $items += "Disco $($d.Number): $model ($sizeGB GiB, $($d.PartitionStyle))$letterStr"
        }
    } catch {
        throw "Falha ao listar discos: $($_.Exception.Message)"
    }
    return $items
}

# -- Plano dry-run -----------------------------------------------------
function Build-Plan {
    param([string]$DiskSelection, [string]$IsoPath, [bool]$Preserve)

    $LinuxTargetGiB = 'NAO MEDIDO'
    $NTFSFreeGiB    = 'NAO MEDIDO'
    $UnallocatedGiB = 'NAO MEDIDO'
    $MaxShrinkGiB   = 'NAO MEDIDO'
    $MinNtfsGiB     = 'NAO MEDIDO'
    $NtfsUsedGiB    = 'NAO MEDIDO'
    $SizingStatus   = 'NENHUMA PARTICAO NTFS ELEGIVEL'
    $EfiStatus      = 'NAO DETECTADA'
    $EfiSizeMB      = 0
    $IsSystemDisk   = $false
    $DiskStyle      = 'DESCONHECIDO'
    $NtfsDrive      = ''
    $TotalDiskGiB   = 0

    if ($DiskSelection -notmatch '^Disco\s+(\d+):') {
        throw 'Selecao de disco invalida. Atualize a lista e selecione um disco real.'
    }
    if (@(Get-DiskListForCombo) -cnotcontains $DiskSelection) {
        throw 'Disco alterado ou removido desde a selecao. Clique Atualizar e selecione novamente.'
    }
    if ($DiskSelection -match '^Disco\s+(\d+):') {
        $diskId = [int]$Matches[1]
        try {
            $diskObject   = Get-Disk -Number $diskId -ErrorAction Stop
            $TotalDiskGiB = [math]::Round($diskObject.Size / 1GB, 2)
            $DiskStyle    = $diskObject.PartitionStyle
            $UnallocatedGiB = [math]::Round($diskObject.LargestFreeExtent / 1GB, 2)
            $IsSystemDisk = Test-IsSystemDisk -DiskNumber $diskId

            $efiParts = @(Get-EfiPartitions -DiskNumber $diskId)
            if ($efiParts.Count -gt 0) {
                $efi = $efiParts[0]
                $EfiStatus = "ENCONTRADA (Part $($efi.PartitionNumber), $($efi.SizeMB) MB)"
                $EfiSizeMB = $efi.SizeMB
            }

            $volumeCandidates = @(
                foreach ($partition in (Get-Partition -DiskNumber $diskId -ErrorAction Stop)) {
                    if ($partition.DriveLetter) {
                        try {
                            $volume = Get-Volume -DriveLetter $partition.DriveLetter -ErrorAction Stop
                            if ($volume.FileSystem -eq 'NTFS') {
                                [pscustomobject]@{
                                    FreeBytes       = $volume.SizeRemaining
                                    UsedBytes       = $volume.Size - $volume.SizeRemaining
                                    TotalBytes      = $volume.Size
                                    Drive           = $partition.DriveLetter
                                    PartitionNumber = $partition.PartitionNumber
                                    CurrentBytes    = $partition.Size
                                    Label           = $volume.FileSystemLabel
                                }
                            }
                        } catch {}
                    }
                }
            )
            if ($volumeCandidates.Count -gt 0) {
                $bestVolume  = $volumeCandidates | Sort-Object FreeBytes -Descending | Select-Object -First 1
                $NTFSFreeGiB = [math]::Round($bestVolume.FreeBytes / 1GB, 2)
                $NtfsUsedGiB = [math]::Round($bestVolume.UsedBytes / 1GB, 2)
                $NtfsDrive   = "$($bestVolume.Drive):"
                try {
                    $supported      = Get-PartitionSupportedSize -DiskNumber $diskId -PartitionNumber $bestVolume.PartitionNumber -ErrorAction Stop
                    $maxShrinkBytes = [math]::Max([double]0, ([double]$bestVolume.CurrentBytes - [double]$supported.SizeMin))
                    $MaxShrinkGiB   = [math]::Round($maxShrinkBytes / 1GB, 2)
                    $MinNtfsGiB     = [math]::Round($supported.SizeMin / 1GB, 2)
                    $safeMarginBytes    = 2GB
                    $effectiveShrink    = [math]::Max([double]0, $maxShrinkBytes - $safeMarginBytes)
                    # Uma ESP nova ocupa espaco do mesmo bloco liberado: nao contar duas vezes.
                    $efiReserveBytes    = if ($EfiSizeMB -eq 0) { 512MB } else { 0 }
                    $linuxBytes         = [math]::Max([double]0, $effectiveShrink - $efiReserveBytes)
                    $LinuxTargetGiB     = [math]::Round($linuxBytes / 1GB, 2)
                    $SizingStatus       = "LIMITE CONSULTADO NO NTFS $($bestVolume.Drive): (margem 2 GiB; ESP nova ate 512 MB se necessaria)"
                } catch {
                    $SizingStatus   = "IMPOSSIVEL CALCULAR REDUCAO SEGURA: $($_.Exception.Message)"
                    $LinuxTargetGiB = 'PENDENTE'
                }
            }
        } catch {
            throw "Impossivel gerar plano confiavel: $($_.Exception.Message)"
        }
    }

    $isoValid   = $false
    $isoSizeGiB = 'N/A'
    if ($IsoPath -and $IsoPath.EndsWith('.iso', [System.StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $IsoPath -PathType Leaf)) {
        $isoValid   = $true
        $isoSizeGiB = [math]::Round((Get-Item -LiteralPath $IsoPath).Length / 1GB, 2)
    }

    $lines = @()
    $lines += '==========================================================='
    $lines += '  CENTRALDARK INSTALLER v3.0 - PLANO DE IMPLANTACAO (DRY-RUN)'
    $lines += '==========================================================='
    $lines += ''

    # -- Preconditions --
    $lines += '-- PRECONDICOES --------------------------------------------'
    $lines += "Disco selecionado  : $DiskSelection"
    $lines += "Tamanho total      : $TotalDiskGiB GiB"
    $lines += "Estilo de particao : $DiskStyle"
    if ($IsSystemDisk) {
        $lines += '*** ATENCAO: DISCO CONTEM SISTEMA WINDOWS (C:) ***'
        $lines += '*** OPERACOES NESTE DISCO EXIGEM CUIDADO REDOBRADO ***'
    }
    $lines += ''
    $lines += "ESP neste disco    : $EfiStatus"
    if ($DiskStyle -eq 'GPT' -and $EfiSizeMB -eq 0) {
        $lines += '  [WARN] Sem ESP neste disco. Verificar ESP em outros discos e firmware UEFI antes de qualquer decisao.'
    }
    if ($DiskStyle -eq 'MBR') {
        $lines += '  [WARN] Disco MBR - dual boot UEFI requer conversao para GPT'
    }
    $lines += ''
    $lines += "ISO selecionada    : $IsoPath"
    if ($isoValid) {
        $lines += "ISO encontrada     : ARQUIVO PRESENTE ($isoSizeGiB GiB); checksum oficial NAO conferido"
    } else {
        $lines += 'ISO encontrada     : PENDENTE - arquivo ISO nao encontrado ou extensao incorreta'
    }
    $lines += "Preservar NTFS     : $(if ($Preserve) {'SIM - dados existentes serao mantidos'} else {'NAO'})"
    if (-not $Preserve) {
        $lines += '  [BLOQUEIO] Ative Preservar arquivos existentes antes de prosseguir'
    }
    $lines += ''

    # -- Sizing --
    $lines += '-- DIMENSIONAMENTO -----------------------------------------'
    $lines += ''
    $lines += '  +----------------------------------------------------------+'
    $lines += '  |  Livre NTFS  =/=  Nao alocado  (sao coisas DIFERENTES) |'
    $lines += '  |  Livre NTFS : pertence a particao, precisa de SHRINK    |'
    $lines += '  |  Nao alocado: fora de qualquer particao, pronto p/ uso  |'
    $lines += '  +----------------------------------------------------------+'
    $lines += ''
    if ($NtfsDrive) {
        $lines += "Volume NTFS alvo   : $NtfsDrive"
        $lines += "  Usado no NTFS    : $NtfsUsedGiB GiB (dados a preservar)"
        $lines += "  Livre no NTFS    : $NTFSFreeGiB GiB (pertence ao NTFS - requer shrink)"
    }
    $lines += "Maior bloco nao alocado: $UnallocatedGiB GiB (LargestFreeExtent; NAO e soma total)"
    $lines += "Reducao NTFS max   : $MaxShrinkGiB GiB (via Get-PartitionSupportedSize)"
    $lines += "NTFS minimo        : $MinNtfsGiB GiB (limite de seguranca do Windows)"
    $lines += "Status do calculo  : $SizingStatus"
    $lines += "Linux estimado     : ate $LinuxTargetGiB GiB (apos margem e reserva EFI se necessaria)"
    $lines += '  [AVISO] Limites sao uma fotografia read-only, NAO garantia de shrink ou backup.'
    $lines += ''

    # -- Phases --
    $lines += '-- FASE 1: Isolar / Preservar NTFS atual ----------------'
    $lines += '   STATUS: PENDENTE (etapa guiada - nenhuma acao automatica)'
    $lines += '   - Backup VERIFICADO dos dados NTFS existentes (nao realizado pelo app)'
    $lines += '   - Verificar integridade com chkdsk /scan (read-only)'
    $lines += '   - Documentar layout atual de particoes'
    $lines += ''
    $lines += '-- FASE 2: Liberar espaco (layout planejado) ------------'
    $lines += '   STATUS: PENDENTE (requer aprovacao explicita do CHEFE)'
    $lines += '   - Reduzir volume NTFS existente para liberar espaco'
    if ($NtfsDrive) {
        $lines += "   - Volume candidato: $NtfsDrive (shrink de ate $MaxShrinkGiB GiB)"
    }
    $lines += '   - Layout proposto:'
    if ($EfiSizeMB -gt 0) {
        $lines += "       EFI (existente)  : $EfiSizeMB MB - sera REUTILIZADA"
    } else {
        $lines += '       EFI (possivel)  : reservar ate 512 MB; consultar ESP de outros discos/UEFI'
        $lines += '       EFI (status)    : NENHUMA CRIACAO AUTOMATICA'
    }
    $lines += "       Linux ext4 /     : ate $LinuxTargetGiB GiB (ESTIMATIVA, nao particao criada)"
    $lines += '       Swap             : arquivo dentro do Linux conforme RAM'
    $lines += "       Dados NTFS       : preservar a ocupacao atual ($NtfsUsedGiB GiB)"
    $lines += ''
    $lines += '-- FASE 3: Instalar openKylin via ISO -------------------'
    $lines += '   STATUS: PENDENTE (etapa guiada - requer boot USB ou UEFI)'
    $lines += '   - Gravar ISO em USB bootavel ou montar via UEFI'
    $lines += '   - Instalar openKylin nas particoes criadas na Fase 2'
    $lines += '   - Configurar locale pt_BR, usuario, hostname'
    $lines += ''
    $lines += '-- FASE 4: Configurar Dual Boot -------------------------'
    $lines += '   STATUS: PENDENTE (etapa guiada - apos instalacao)'
    $lines += '   - Instalar/atualizar GRUB na particao EFI'
    $lines += '   - Detectar Windows Boot Manager existente'
    $lines += '   - Configurar menu de selecao GRUB + Windows'
    $lines += ''
    $lines += '-- FASE 5: WSL opcional para acesso a dados --------------'
    $lines += '   STATUS: OPCIONAL / PENDENTE (etapa guiada - limitacoes tecnicas)'
    $lines += '   LIMITACAO HONESTA:'
    $lines += '   O WSL2 opera sobre kernel Linux proprio em VM leve (Hyper-V).'
    $lines += '   Ele NAO pode montar/acessar nativamente uma particao ext4 fisica'
    $lines += '   como se fosse o MESMO sistema Linux instalado no disco.'
    $lines += '   Opcoes reais (nenhuma e equivalente a boot nativo):'
    $lines += '   a) wsl --mount para acessar dados da particao ext4 (leitura do disco)'
    $lines += '   b) Importar snapshot .tar como distro WSL separada (copia independente)'
    $lines += '   c) Compartilhar dados via particao NTFS acessivel por ambos'
    $lines += '   NAO sera criada segunda capsula WSL sem validacao real.'
    $lines += ''
    $lines += '-- FASE 6: Hermes CLI dentro do openKylin ---------------'
    $lines += '   STATUS: PENDENTE (somente DEPOIS de instalar openKylin)'
    $lines += '   - Inicializar o openKylin instalado e validar rede/terminal'
    $lines += '   - Instalar Hermes CLI DENTRO do openKylin (nao no Windows)'
    $lines += '   - Verificar CLI e dependencias no proprio Linux apos instalacao'
    $lines += '   - Sem necessidade de Hermes Desktop no Windows'
    $lines += ''
    $lines += '-- FASE 7: Validacao final ------------------------------'
    $lines += '   STATUS: PENDENTE'
    $lines += '   - Testar boot em Linux e retorno ao Windows'
    $lines += '   - Validar Hermes CLI NO openKylin instalado (se autorizado)'
    $lines += '   - Se WSL for usado, validar acesso a dados, nao ao mesmo boot'
    $lines += '   - Verificar integridade dos dados NTFS preservados'
    $lines += '   - Exportar relatorio final'
    $lines += ''
    $lines += '-- FASE 8: Reconciliar CentralDark no openKylin ---------'
    $lines += '   STATUS: PENDENTE / POS-BOOT (planejamento, sem aplicar)'
    $lines += '   - Validar primeiro boot e identificar volumes por UUID/label, nao por letra K:'
    $lines += '   - Montar NTFS preservado inicialmente SOMENTE LEITURA'
    $lines += '   - Confirmar backup externo restauravel + inventario + hashes antes de copiar dados'
    $lines += '   - Distinguir dados preservados, codigo Git, credenciais privadas e runtime descartavel'
    $lines += '   - Resolver CENTRALDARK_ROOT no Linux (nao presumir /root ou /opt)'
    $lines += '   - Reutilizar instalador/restore canonicos do repo; configurar apenas bindings do ambiente'
    $lines += '   - Nao importar .env/tokens/servicos/estado da instalacao antiga sem allowlist'
    $lines += '   - Executar replay das receitas, validar arquivos/servicos e emitir receipts'
    $lines += '   - Espaco restante/expansao: planejar separadamente e verificar antes de qualquer resize'
    $lines += '   - Perfil: CASA ou VPS; acesso PUBLICO e configuracao INDEPENDENTE (nao padrao)'
    $lines += '   - POST_BOOT_RECONCILIATION=UNKNOWN ate readback real no openKylin'
    $lines += ''
    $lines += '==========================================================='
    $lines += '  SOFTWARE EM MODO PLANEJAMENTO: INSTALACAO FISICA PENDENTE'
    $lines += '  NENHUMA ACAO DESTRUTIVA SERA EXECUTADA SEM APROVACAO'
    $lines += '==========================================================='
    return $lines
}

# -- Verificacao read-only ---------------------------------------------
function Invoke-ReadOnlyVerify {
    param([string]$IsoPath)
    $lines = @()
    $lines += '-- Verificacao Read-Only v3.0 ---------------------------'
    $lines += ''

    $preflight = Get-PreflightResult -IsoPath $IsoPath
    $lines += '-- Preflight do instalador -------------------------------'
    $lines += $(if ($preflight.Admin) { '[OK] Processo elevado como Administrador' } else { '[WARN] Processo nao elevado como Administrador' })
    foreach ($message in $preflight.Messages) { $lines += $message }
    if ($preflight.Iso) {
        $lines += "[OK] ISO legivel e nao vazia: $([math]::Round($preflight.IsoSize / 1GB, 2)) GiB"
    }
    $lines += ''

    if (Test-IsAdmin) {
        $lines += '[OK] Executando como Administrador'
    } else {
        $lines += '[WARN] NAO esta executando como Administrador'
        $lines += '       Algumas consultas de disco podem falhar sem elevacao.'
    }
    $lines += ''

    if ($preflight.Iso) {
        $isoItem = Get-Item -LiteralPath $IsoPath
        $isoSize = [math]::Round($isoItem.Length / 1GB, 2)
        $lines += "[OK] ISO encontrada: $IsoPath ($isoSize GiB)"
        $lines += "     Modificada em: $($isoItem.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss'))"
    } elseif ($IsoPath) {
        $lines += "[WARN] ISO nao encontrada: $IsoPath"
    } else {
        $lines += '[WARN] Nenhuma ISO selecionada'
    }
    $lines += ''

    try {
        $disks = @(Get-Disk -ErrorAction Stop)
        $lines += "[OK] Get-Disk: $($disks.Count) disco(s) detectado(s)"
        foreach ($d in $disks) {
            $sysTag = ''
            if (Test-IsSystemDisk -DiskNumber $d.Number) { $sysTag = ' [SISTEMA - NAO DESTINAR]' }
            $lines += "     Disco $($d.Number): $($d.FriendlyName) ($([math]::Round($d.Size / 1GB,2)) GiB, $($d.PartitionStyle))$sysTag"
        }
    } catch {
        $lines += "[ERRO] Get-Disk falhou: $($_.Exception.Message)"
    }
    $lines += ''

    try {
        $partCount = @(Get-Partition -ErrorAction Stop).Count
        $lines += "[OK] Get-Partition: $partCount particao(oes) detectada(s)"
    } catch {
        $lines += "[ERRO] Get-Partition falhou: $($_.Exception.Message)"
    }

    $lines += ''
    $lines += '-- Particoes EFI -------------------------------------------'
    try {
        $allDisks = Get-Disk -ErrorAction Stop
        $foundEfi = $false
        foreach ($d in $allDisks) {
            $efis = Get-EfiPartitions -DiskNumber $d.Number
            foreach ($e in $efis) {
                $lines += "[OK] EFI encontrada: Disco $($d.Number), Part $($e.PartitionNumber), $($e.SizeMB) MB"
                $foundEfi = $true
            }
        }
        if (-not $foundEfi) {
            $lines += '[WARN] Nenhuma particao EFI encontrada em nenhum disco'
        }
    } catch {
        $lines += "[ERRO] Falha ao verificar EFI: $($_.Exception.Message)"
    }

    $lines += ''
    $lines += '-- WSL (somente leitura) --------------------------------'
    try {
        $wslExe = Get-Command wsl.exe -ErrorAction Stop
        $lines += "[OK] wsl.exe encontrado: $($wslExe.Source)"
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName               = $wslExe.Source
            $psi.Arguments              = '--list --verbose'
            $psi.UseShellExecute        = $false
            $psi.CreateNoWindow         = $true
            $psi.WindowStyle            = [System.Diagnostics.ProcessWindowStyle]::Hidden
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError  = $true
            $psi.StandardOutputEncoding = [System.Text.Encoding]::Unicode
            $wslProc = [System.Diagnostics.Process]::Start($psi)
            if ($null -eq $wslProc) { throw 'Falha ao iniciar consulta WSL.' }
            try {
                $outTask = $wslProc.StandardOutput.ReadToEndAsync()
                $errTask = $wslProc.StandardError.ReadToEndAsync()
                $exited  = $wslProc.WaitForExit(10000)
                if (-not $exited) {
                    try { $wslProc.Kill(); [void]$wslProc.WaitForExit(2000) } catch {}
                    $lines += '[WARN] wsl --list excedeu tempo limite (10s)'
                } else {
                    [void]$outTask.Wait(2000)
                    [void]$errTask.Wait(2000)
                    $wslOut = if ($outTask.IsCompleted) { $outTask.Result } else { '' }
                    $wslErr = if ($errTask.IsCompleted) { $errTask.Result } else { '' }
                    if ($wslProc.ExitCode -ne 0) {
                        $lines += "[WARN] WSL terminou com codigo $($wslProc.ExitCode)"
                    }
                    if ($wslOut) {
                        foreach ($wl in ($wslOut -split "`r?`n")) {
                            if ($wl.Trim()) { $lines += "  $wl" }
                        }
                    }
                    if ($wslErr -and $wslErr.Trim()) {
                        $lines += "[WARN] stderr: $($wslErr.Trim())"
                    }
                }
            } finally {
                $wslProc.Dispose()
            }
        } catch {
            $lines += "[WARN] wsl --list falhou: $($_.Exception.Message)"
        }
    } catch {
        $lines += '[WARN] wsl.exe nao encontrado no PATH'
    }

    $lines += ''
    $lines += '-- WSL --mount (disponibilidade) ------------------------'
    try {
        $psi2 = New-Object System.Diagnostics.ProcessStartInfo
        $psi2.FileName               = 'wsl.exe'
        $psi2.Arguments              = '--help'
        $psi2.UseShellExecute        = $false
        $psi2.CreateNoWindow         = $true
        $psi2.RedirectStandardOutput = $true
        $psi2.RedirectStandardError  = $true
        $psi2.StandardOutputEncoding = [System.Text.Encoding]::Unicode
        $helpProc = [System.Diagnostics.Process]::Start($psi2)
        if ($helpProc) {
            try {
                # Ler os dois pipes assincronamente antes do timeout evita deadlock
                # quando o comando produz mais dados que a capacidade de um pipe.
                $helpOutTask = $helpProc.StandardOutput.ReadToEndAsync()
                $helpErrTask = $helpProc.StandardError.ReadToEndAsync()
                if (-not $helpProc.WaitForExit(5000)) {
                    try { $helpProc.Kill(); [void]$helpProc.WaitForExit(2000) } catch {}
                    $lines += '[INFO] wsl --help excedeu o timeout de 5s; WSL e opcional e nao requisito do Hermes CLI nativo'
                } else {
                    [void]$helpOutTask.Wait(2000)
                    [void]$helpErrTask.Wait(2000)
                    $helpOut = if ($helpOutTask.IsCompleted) { $helpOutTask.Result } else { '' }
                    if ($helpProc.ExitCode -eq 0 -and $helpOut -match '--mount') {
                        $lines += '[OK] wsl --mount anunciado na ajuda (NAO testado nem montado)'
                    } else {
                        $lines += '[INFO] wsl --mount nao confirmado; opcional e NAO necessario para Hermes CLI no openKylin'
                    }
                }
            } finally {
                $helpProc.Dispose()
            }
        }
    } catch {
        $lines += '[INFO] Nao foi possivel verificar wsl --mount (opcional, sem bloqueio do Hermes CLI)'
    }

    $lines += ''
    $lines += '-- Hermes CLI no openKylin (etapa futura) ----------------'
    $lines += '[INFO] PENDENTE: instalar Hermes CLI DENTRO do openKylin, apos instalar e iniciar o Linux.'
    $lines += '[INFO] Nao exigir nem procurar Hermes Desktop no Windows.'
    $lines += '[INFO] Instalacao e teste do Hermes CLI no Linux NAO executados nesta verificacao.'

    $lines += ''
    $lines += '-- Fim da verificacao -----------------------------------'
    return $lines
}

# -- Exportar relatorio ------------------------------------------------
function Export-Report {
    param([string]$Content)
    $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
    $path = Join-Path (Get-InstallerDataDir) "CentralDark-Relatorio_$ts.txt"
    try {
        $Content | Out-File -FilePath $path -Encoding UTF8 -ErrorAction Stop
        Write-Status "Relatorio exportado: $path" 'OK'
    } catch {
        Write-Status "Erro ao exportar: $($_.Exception.Message)" 'ERROR'
    }
}

# ======================================================================
#  GUI Principal
# ======================================================================
function Show-MainWindow {
    $form = New-Object System.Windows.Forms.Form
    $form.Text            = 'CENTRALDARK INSTALLER'
    $form.Size            = New-Object System.Drawing.Size(960, 800)
    $form.StartPosition   = 'CenterScreen'
    $form.BackColor       = $script:BgDark
    $form.ForeColor       = $script:FgLight
    $form.FormBorderStyle = 'FixedSingle'
    $form.MaximizeBox     = $false
    $form.Font            = New-Object System.Drawing.Font('Segoe UI', 9)

    $toolTip = New-Object System.Windows.Forms.ToolTip
    $toolTip.InitialDelay = 400
    $toolTip.ReshowDelay  = 200

    # -- Titulo --------------------------------------------------------
    $lblTitle = New-Object System.Windows.Forms.Label
    $lblTitle.Text      = 'CENTRALDARK INSTALLER'
    $lblTitle.Font      = New-Object System.Drawing.Font('Segoe UI', 18, [System.Drawing.FontStyle]::Bold)
    $lblTitle.ForeColor = $script:AccentCyan
    $lblTitle.AutoSize  = $true
    $lblTitle.Location  = New-Object System.Drawing.Point(24, 14)
    $form.Controls.Add($lblTitle)

    $lblSub = New-Object System.Windows.Forms.Label
    $lblSub.Text      = [char]0x25CF + '  Capsula Linux  |  Dual Boot  |  WSL  |  Hermes CLI no Linux'
    $lblSub.Font      = New-Object System.Drawing.Font('Segoe UI', 9.5)
    $lblSub.ForeColor = $script:FgDim
    $lblSub.AutoSize  = $true
    $lblSub.Location  = New-Object System.Drawing.Point(26, 52)
    $form.Controls.Add($lblSub)

    $lblVersion = New-Object System.Windows.Forms.Label
    $lblVersion.Text      = 'v3.0'
    $lblVersion.Font      = New-Object System.Drawing.Font('Segoe UI', 8)
    $lblVersion.ForeColor = $script:FgDim
    $lblVersion.AutoSize  = $true
    $lblVersion.Location  = New-Object System.Drawing.Point(870, 20)
    $form.Controls.Add($lblVersion)

    $isAdmin = Test-IsAdmin
    $lblAdmin = New-Object System.Windows.Forms.Label
    $lblAdmin.Font     = New-Object System.Drawing.Font('Segoe UI', 7.5)
    $lblAdmin.AutoSize = $true
    $lblAdmin.Location = New-Object System.Drawing.Point(820, 36)
    if ($isAdmin) {
        $lblAdmin.Text      = 'Admin: SIM'
        $lblAdmin.ForeColor = $script:AccentGreen
    } else {
        $lblAdmin.Text      = 'Admin: NAO'
        $lblAdmin.ForeColor = $script:AccentYellow
    }
    $form.Controls.Add($lblAdmin)

    # -- Painel de controle --------------------------------------------
    $panel = New-Object System.Windows.Forms.Panel
    $panel.Location  = New-Object System.Drawing.Point(16, 82)
    $panel.Size      = New-Object System.Drawing.Size(912, 150)
    $panel.BackColor = $script:BgPanel
    $form.Controls.Add($panel)

    $lblDisk = New-Object System.Windows.Forms.Label
    $lblDisk.Text      = 'Disco fisico:'
    $lblDisk.Location  = New-Object System.Drawing.Point(12, 12)
    $lblDisk.AutoSize  = $true
    $lblDisk.ForeColor = $script:FgLight
    $panel.Controls.Add($lblDisk)

    $cmbDisk = New-Object System.Windows.Forms.ComboBox
    $cmbDisk.Location      = New-Object System.Drawing.Point(110, 9)
    $cmbDisk.Size          = New-Object System.Drawing.Size(580, 28)
    $cmbDisk.DropDownStyle = 'DropDownList'
    $cmbDisk.BackColor     = $script:BgInput
    $cmbDisk.ForeColor     = $script:FgLight
    $cmbDisk.FlatStyle     = 'Flat'
    $panel.Controls.Add($cmbDisk)

    $btnRefreshDisks = New-DarkButton -Text 'Atualizar' -X 700 -Y 7 -W 90 -H 28
    $panel.Controls.Add($btnRefreshDisks)
    $toolTip.SetToolTip($btnRefreshDisks, 'Recarregar lista de discos fisicos')

    $lblDiskWarn = New-Object System.Windows.Forms.Label
    $lblDiskWarn.Text      = ''
    $lblDiskWarn.Location  = New-Object System.Drawing.Point(800, 12)
    $lblDiskWarn.Size      = New-Object System.Drawing.Size(105, 18)
    $lblDiskWarn.ForeColor = $script:AccentRed
    $lblDiskWarn.Font      = New-Object System.Drawing.Font('Segoe UI', 7.5, [System.Drawing.FontStyle]::Bold)
    $panel.Controls.Add($lblDiskWarn)

    $lblIso = New-Object System.Windows.Forms.Label
    $lblIso.Text      = 'ISO Linux:'
    $lblIso.Location  = New-Object System.Drawing.Point(12, 48)
    $lblIso.AutoSize  = $true
    $lblIso.ForeColor = $script:FgLight
    $panel.Controls.Add($lblIso)

    $txtIso = New-Object System.Windows.Forms.TextBox
    $txtIso.Location    = New-Object System.Drawing.Point(110, 45)
    $txtIso.Size        = New-Object System.Drawing.Size(610, 24)
    $txtIso.BackColor   = $script:BgInput
    $txtIso.ForeColor   = $script:FgLight
    $txtIso.BorderStyle = 'FixedSingle'
    $txtIso.Text        = $script:IsoDefault
    $panel.Controls.Add($txtIso)

    $btnBrowse = New-DarkButton -Text '...' -X 730 -Y 43 -W 42 -H 28
    $panel.Controls.Add($btnBrowse)
    $toolTip.SetToolTip($btnBrowse, 'Selecionar arquivo ISO')

    $lblIsoHash = New-Object System.Windows.Forms.Label
    $lblIsoHash.Text      = ''
    $lblIsoHash.Location  = New-Object System.Drawing.Point(110, 74)
    $lblIsoHash.Size      = New-Object System.Drawing.Size(680, 16)
    $lblIsoHash.ForeColor = $script:FgDim
    $lblIsoHash.Font      = New-Object System.Drawing.Font('Consolas', 7)
    $panel.Controls.Add($lblIsoHash)

    $chkPreserve = New-Object System.Windows.Forms.CheckBox
    $chkPreserve.Text      = 'Preservar arquivos existentes'
    $chkPreserve.Checked   = $true
    $chkPreserve.Location  = New-Object System.Drawing.Point(110, 94)
    $chkPreserve.AutoSize  = $true
    $chkPreserve.ForeColor = $script:FgLight
    $chkPreserve.FlatStyle = 'Flat'
    $panel.Controls.Add($chkPreserve)

    $lblPhase = New-Object System.Windows.Forms.Label
    $lblPhase.Text      = 'Passos 1-5: analise e planejamento | 6-8: somente orientacao'
    $lblPhase.Location  = New-Object System.Drawing.Point(110, 122)
    $lblPhase.AutoSize  = $true
    $lblPhase.ForeColor = $script:AccentCyan
    $lblPhase.Font      = New-Object System.Drawing.Font('Segoe UI', 8.5, [System.Drawing.FontStyle]::Italic)
    $panel.Controls.Add($lblPhase)

    # -- Fluxo numerado: 1-5 analise/planejamento; 6-8 somente guiado --
    $y0 = 242
    $btnAnalyze  = New-DarkButton -Text '1 ANALISAR'           -X 16  -Y $y0 -W 120
    $btnPlan     = New-DarkButton -Text '2 PREPARAR PLANO'     -X 144 -Y $y0 -W 156
    $btnVerify   = New-DarkButton -Text '3 VERIFICAR'          -X 308 -Y $y0 -W 120
    $btnHash     = New-DarkButton -Text '4 SHA256 ISO'         -X 436 -Y $y0 -W 122
    $btnExport   = New-DarkButton -Text '5 EXPORTAR RELATORIO' -X 566 -Y $y0 -W 204
    $btnClose    = New-DarkButton -Text 'FECHAR'               -X 824 -Y $y0 -W 104
    $btnClose.FlatAppearance.BorderColor = $script:AccentRed

    # Botoes de orientacao: nunca reparticionam, instalam, alteram boot ou WSL.
    $btnInstall  = New-DarkButton -Text '6 INSTALAR (GUIADO)'   -X 16  -Y ($y0 + 40) -W 214
    $btnDualBoot = New-DarkButton -Text '7 DUAL BOOT (GUIADO)' -X 238 -Y ($y0 + 40) -W 206
    $btnHermes   = New-DarkButton -Text '8 HERMES CLI (GUIADO)' -X 452 -Y ($y0 + 40) -W 220
    foreach ($guidedButton in @($btnInstall, $btnDualBoot, $btnHermes)) {
        $guidedButton.FlatAppearance.BorderColor = $script:AccentYellow
    }

    $lblGuided = New-Object System.Windows.Forms.Label
    $lblGuided.Text = 'ETAPAS GUIADAS: NAO INSTALAM'
    $lblGuided.Location = New-Object System.Drawing.Point(688, ($y0 + 49))
    $lblGuided.Size = New-Object System.Drawing.Size(240, 22)
    $lblGuided.Font = New-Object System.Drawing.Font('Segoe UI', 7.5, [System.Drawing.FontStyle]::Bold)
    $lblGuided.ForeColor = $script:AccentYellow
    $form.Controls.Add($lblGuided)

    $toolTip.SetToolTip($btnAnalyze,  'Passo 1: inventario de discos, somente leitura')
    $toolTip.SetToolTip($btnPlan,     'Passo 2: plano dry-run, sem alteracoes no disco')
    $toolTip.SetToolTip($btnVerify,   'Passo 3: diagnostico read-only; Hermes CLI no Linux sera instalado depois, nao verificado no Windows')
    $toolTip.SetToolTip($btnHash,     'Passo 4: calcular SHA256 da ISO, apenas leitura; comparar com checksum oficial')
    $toolTip.SetToolTip($btnExport,   'Passo 5: salvar relatorio na pasta do Installer')
    $toolTip.SetToolTip($btnInstall,  'Passo 6: SOMENTE checklist, instalacao Linux pendente')
    $toolTip.SetToolTip($btnDualBoot, 'Passo 7: SOMENTE checklist, nao modifica boot ou EFI')
    $toolTip.SetToolTip($btnHermes,   'Passo 8 (GUIADO): Hermes CLI sera instalado no openKylin depois do boot; WSL opcional e separado')
    $toolTip.SetToolTip($btnClose,    'Fechar o instalador')

    $form.Controls.AddRange(@(
        $btnAnalyze, $btnPlan, $btnVerify, $btnHash, $btnExport,
        $btnInstall, $btnDualBoot, $btnHermes, $btnClose
    ))

    # -- Indicadores: apenas fases, na mesma ordem logica da interface --
    $phaseY = $y0 + 80
    $phaseLabels = @{}
    $phaseNumbers = @{ 'ANALISAR' = 1; 'PREPARAR' = 2; 'VERIFICAR' = 3; 'INSTALAR' = 6; 'DUAL BOOT' = 7; 'HERMES CLI' = 8 }
    $phaseX = 16
    $phaseW = 145
    foreach ($pName in $script:PhaseNames) {
        $lbl = New-Object System.Windows.Forms.Label
        $lbl.Text        = "$($phaseNumbers[$pName]) $pName"
        $lbl.Location    = New-Object System.Drawing.Point($phaseX, $phaseY)
        $lbl.Size        = New-Object System.Drawing.Size($phaseW, 20)
        $lbl.BackColor   = $script:BgPanel
        $lbl.ForeColor   = $script:FgDim
        $lbl.Font        = New-Object System.Drawing.Font('Segoe UI', 7.5, [System.Drawing.FontStyle]::Bold)
        $lbl.TextAlign   = [System.Drawing.ContentAlignment]::MiddleCenter
        $lbl.BorderStyle = 'FixedSingle'
        $form.Controls.Add($lbl)
        $phaseLabels[$pName] = $lbl
        $phaseX += $phaseW + 2
    }

    # -- Separador visual ---------------------------------------------
    $sepY = $phaseY + 26
    $separator = New-Object System.Windows.Forms.Label
    $separator.Location  = New-Object System.Drawing.Point(16, $sepY)
    $separator.Size      = New-Object System.Drawing.Size(912, 1)
    $separator.BackColor = $script:AccentCyan
    $form.Controls.Add($separator)

    # -- Area de saida -------------------------------------------------
    $outY = $sepY + 4
    $script:txtOutput = New-Object System.Windows.Forms.TextBox
    $script:txtOutput.Location    = New-Object System.Drawing.Point(16, $outY)
    $script:txtOutput.Size        = New-Object System.Drawing.Size(912, 366)
    $script:txtOutput.Multiline   = $true
    $script:txtOutput.ScrollBars  = 'Vertical'
    $script:txtOutput.ReadOnly    = $true
    $script:txtOutput.BackColor   = $script:BgInput
    $script:txtOutput.ForeColor   = $script:FgLight
    $script:txtOutput.Font        = New-Object System.Drawing.Font('Consolas', 9)
    $script:txtOutput.BorderStyle = 'FixedSingle'
    $form.Controls.Add($script:txtOutput)

    # -- Barra de status inferior --------------------------------------
    $barY = $outY + 366 + 4
    $script:lblStatusBar = New-Object System.Windows.Forms.Label
    $script:lblStatusBar.Location  = New-Object System.Drawing.Point(16, $barY)
    $script:lblStatusBar.Size      = New-Object System.Drawing.Size(912, 22)
    $script:lblStatusBar.BackColor = $script:BgPanel
    $script:lblStatusBar.ForeColor = $script:FgDim
    $script:lblStatusBar.Font      = New-Object System.Drawing.Font('Segoe UI', 8)
    try {
        $null = Get-InstallerDataDir
        $script:lblStatusBar.Text = '  Pronto | Programa: ' + $script:InstallerDir + ' | Dados: ' + $script:DataDir
    } catch {
        $script:lblStatusBar.Text = '  Pronto | Pasta de dados sera criada ao exportar'
    }
    $script:lblStatusBar.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $form.Controls.Add($script:lblStatusBar)

    # -- Helper: update phase indicator --------------------------------
    $updatePhase = {
        param([string]$Phase, [string]$Status)
        $script:PhaseStatus[$Phase] = $Status
        $lbl = $phaseLabels[$Phase]
        if (-not $lbl) { return }
        switch ($Status) {
            'CONCLUIDO' {
                $lbl.BackColor = $script:AccentGreen
                $lbl.ForeColor = $script:BgDark
            }
            'EM CURSO' {
                $lbl.BackColor = $script:AccentCyan
                $lbl.ForeColor = $script:BgDark
            }
            'GUIADO' {
                $lbl.BackColor = $script:AccentYellow
                $lbl.ForeColor = $script:BgDark
            }
            default {
                $lbl.BackColor = $script:BgPanel
                $lbl.ForeColor = $script:FgDim
            }
        }
    }

    # -- Helper: update button states ----------------------------------
    $updateButtons = {
        $hasDisk = $cmbDisk.SelectedIndex -ge 0
        $btnPlan.Enabled = $hasDisk
        if ($hasDisk) {
            $btnPlan.BackColor = $script:BtnBg
            $btnPlan.FlatAppearance.BorderColor = $script:AccentCyan
        } else {
            $btnPlan.BackColor = $script:BtnDisabled
            $btnPlan.FlatAppearance.BorderColor = $script:FgDim
        }
    }

    # -- Eventos -------------------------------------------------------
    $loadDisks = {
        $cmbDisk.Items.Clear()
        $cmbDisk.SelectedIndex = -1
        $lblDiskWarn.Text = ''
        try {
            $items = Get-DiskListForCombo
            foreach ($i in $items) { [void]$cmbDisk.Items.Add($i) }
            if ($items.Count -eq 0) { Write-Status 'Nenhum disco fisico detectado.' 'WARN' }
        } catch {
            Write-Status "Lista de discos indisponivel: $($_.Exception.Message)" 'ERROR'
            $lblDiskWarn.Text = 'SEM ACESSO'
        }
        & $updateButtons
    }

    $cmbDisk.Add_SelectedIndexChanged({
        $lblDiskWarn.Text = ''
        if ($cmbDisk.SelectedItem -match '^Disco\s+(\d+):') {
            $diskNum = [int]$Matches[1]
            try {
                if (Test-IsSystemDisk -DiskNumber $diskNum) {
                    $lblDiskWarn.Text = 'DISCO SISTEMA!'
                }
            } catch {
                $lblDiskWarn.Text = 'NAO VERIFICADO'
                Write-Status "Seguranca do disco nao verificada: $($_.Exception.Message)" 'WARN'
            }
        }
        & $updateButtons
    })

    $btnRefreshDisks.Add_Click($loadDisks)
    $form.Add_Shown($loadDisks)

    $btnBrowse.Add_Click({
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = 'ISO Files (*.iso)|*.iso|All Files (*.*)|*.*'
        $dlg.InitialDirectory = 'E:\VMs'
        if ($dlg.ShowDialog() -eq 'OK') {
            $txtIso.Text = $dlg.FileName
            $lblIsoHash.Text = ''
        }
    })

    # Hash por blocos no WinForms Timer: a GUI continua responsiva e sem reentrancia
    # perigosa via Application.DoEvents. Nenhum dado e escrito na ISO.
    $script:HashTimer = New-Object System.Windows.Forms.Timer
    $script:HashTimer.Interval = 15
    $script:HashStream = $null
    $script:HashAlgo = $null
    $script:HashBuffer = New-Object 'byte[]' (4MB)
    $script:HashBytesRead = [long]0
    $script:HashTotalBytes = [long]0

    $finishHash = {
        param([string]$Result, [bool]$Success)
        $script:HashTimer.Stop()
        if ($script:HashStream) {
            $script:HashStream.Dispose()
            $script:HashStream = $null
        }
        if ($script:HashAlgo) {
            $script:HashAlgo.Dispose()
            $script:HashAlgo = $null
        }
        $btnHash.Enabled = $true
        $btnBrowse.Enabled = $true
        $txtIso.ReadOnly = $false
        if ($Success) {
            $lblIsoHash.Text = "SHA256: $Result"
            Write-Status "SHA256 da ISO: $Result" 'OK'
        } else {
            $lblIsoHash.Text = 'SHA256 indisponivel'
            Write-Status "Falha ao calcular hash: $Result" 'ERROR'
        }
        $script:lblStatusBar.Text = '  Pronto | Pasta: ' + $script:InstallerDir
    }

    $script:HashTimer.Add_Tick({
        try {
            $n = $script:HashStream.Read($script:HashBuffer, 0, $script:HashBuffer.Length)
            if ($n -gt 0) {
                [void]$script:HashAlgo.TransformBlock($script:HashBuffer, 0, $n, $script:HashBuffer, 0)
                $script:HashBytesRead += $n
                $percent = if ($script:HashTotalBytes -gt 0) {
                    [math]::Round(100 * $script:HashBytesRead / $script:HashTotalBytes, 1)
                } else { 100 }
                $lblIsoHash.Text = "SHA256: $percent% calculado..."
                $script:lblStatusBar.Text = "  Calculando SHA256: $percent% (somente leitura)"
            } else {
                [void]$script:HashAlgo.TransformFinalBlock([byte[]]@(), 0, 0)
                $hash = [BitConverter]::ToString($script:HashAlgo.Hash).Replace('-', '').ToLowerInvariant()
                & $finishHash $hash $true
            }
        } catch {
            & $finishHash $_.Exception.Message $false
        }
    })

    $btnHash.Add_Click({
        $isoPath = $txtIso.Text
        if (-not $isoPath -or -not $isoPath.EndsWith('.iso', [StringComparison]::OrdinalIgnoreCase) -or
            -not (Test-Path -LiteralPath $isoPath -PathType Leaf)) {
            Write-Status 'Selecione um arquivo ISO existente antes de calcular SHA256.' 'WARN'
            return
        }
        try {
            $script:HashStream = [System.IO.File]::OpenRead($isoPath)
            $script:HashAlgo = [System.Security.Cryptography.SHA256]::Create()
            $script:HashTotalBytes = $script:HashStream.Length
            $script:HashBytesRead = [long]0
            $lblIsoHash.Text = 'SHA256: 0% calculado...'
            $btnHash.Enabled = $false
            $btnBrowse.Enabled = $false
            $txtIso.ReadOnly = $true
            $script:HashTimer.Start()
        } catch {
            & $finishHash $_.Exception.Message $false
        }
    })

    $form.Add_FormClosing({
        if ($script:HashTimer.Enabled) { $script:HashTimer.Stop() }
        if ($script:HashStream) { $script:HashStream.Dispose(); $script:HashStream = $null }
        if ($script:HashAlgo) { $script:HashAlgo.Dispose(); $script:HashAlgo = $null }
    })
    $form.Add_FormClosed({ $script:HashTimer.Dispose() })

    $btnAnalyze.Add_Click({
        try {
            $script:txtOutput.Clear()
            $script:lblStatusBar.Text = '  Analisando discos...'
            & $updatePhase 'ANALISAR' 'EM CURSO'
            Write-Status 'Iniciando inventario de discos fisicos...'
            Write-Status ''
            $inv = Get-DiskInventory
            foreach ($line in $inv) {
                $script:txtOutput.AppendText("$line`r`n")
            }
            Write-Status ''
            $partial = @($inv | Where-Object { $_ -match 'erro ao ler particoes|VOLUME NAO CONSULTADO' }).Count -gt 0
            if ($partial) {
                Write-Status 'Inventario parcial: algumas particoes ou volumes nao puderam ser consultados.' 'WARN'
                & $updatePhase 'ANALISAR' 'GUIADO'
                $script:lblStatusBar.Text = '  Inventario parcial (avisos)'
            } else {
                Write-Status 'Inventario concluido (somente leitura).' 'OK'
                & $updatePhase 'ANALISAR' 'CONCLUIDO'
                $script:lblStatusBar.Text = '  Inventario concluido | Pasta: ' + $script:InstallerDir
            }
        } catch {
            Write-Status "Erro no inventario: $($_.Exception.Message)" 'ERROR'
            & $updatePhase 'ANALISAR' 'PENDENTE'
            $script:lblStatusBar.Text = '  Erro durante inventario'
        }
    })

    $btnPlan.Add_Click({
        try {
            if (-not $cmbDisk.SelectedItem) {
                Write-Status 'Selecione um disco fisico antes de gerar o plano.' 'WARN'
                return
            }
            $script:txtOutput.Clear()
            $script:lblStatusBar.Text = '  Gerando plano...'
            & $updatePhase 'PREPARAR' 'EM CURSO'
            Write-Status 'Gerando plano dry-run...'
            Write-Status ''
            $plan = Build-Plan -DiskSelection $cmbDisk.SelectedItem `
                               -IsoPath $txtIso.Text `
                               -Preserve $chkPreserve.Checked
            foreach ($line in $plan) {
                $script:txtOutput.AppendText("$line`r`n")
            }
            Write-Status ''
            $incomplete = @($plan | Where-Object {
                $_ -match '\[BLOQUEIO\]|ISO encontrada\s+: PENDENTE|IMPOSSIVEL CALCULAR|Linux estimado\s+: ate (?:PENDENTE|NAO MEDIDO|0 GiB)'
            }).Count -gt 0
            if ($incomplete) {
                Write-Status 'Plano incompleto: precondicoes pendentes. Nenhuma alteracao no disco.' 'WARN'
                & $updatePhase 'PREPARAR' 'GUIADO'
                $script:lblStatusBar.Text = '  Plano incompleto: revisar precondicoes'
            } else {
                Write-Status 'Plano dry-run gerado; isto NAO autoriza instalar ou particionar.' 'OK'
                & $updatePhase 'PREPARAR' 'CONCLUIDO'
                $script:lblStatusBar.Text = '  Plano dry-run gerado | Pasta: ' + $script:InstallerDir
            }
        } catch {
            Write-Status "Erro ao gerar plano: $($_.Exception.Message)" 'ERROR'
            & $updatePhase 'PREPARAR' 'PENDENTE'
            $script:lblStatusBar.Text = '  Erro ao gerar plano'
        }
    })

    $btnInstall.Add_Click({
        $script:txtOutput.Clear()
        & $updatePhase 'INSTALAR' 'GUIADO'
        Write-Status '======================================================'
        Write-Status '  INSTALAR LINUX - ETAPA GUIADA'
        Write-Status '======================================================'
        Write-Status ''
        Write-Status 'STATUS: PENDENTE - requer acao manual do CHEFE' 'PHASE'
        Write-Status ''
        Write-Status 'Esta etapa NAO pode ser executada automaticamente.'
        Write-Status 'A instalacao requer boot a partir de midia USB/UEFI.'
        Write-Status ''
        Write-Status 'Checklist de pre-requisitos:'
        Write-Status '  [ ] Plano de dimensionamento gerado e revisado'
        Write-Status '  [ ] Backup dos dados NTFS existentes realizado'
        Write-Status '  [ ] Espaco liberado no disco (shrink NTFS concluido)'
        Write-Status '  [ ] USB bootavel criado com a ISO openKylin'
        Write-Status '  [ ] BIOS/UEFI configurada para boot USB'
        Write-Status ''
        Write-Status 'Passos da instalacao (executar manualmente):'
        Write-Status '  1. Criar USB bootavel (usar Rufus, Ventoy ou dd)'
        Write-Status '  2. Reiniciar e dar boot pelo USB'
        Write-Status '  3. Instalar openKylin na particao ext4 preparada'
        Write-Status '  4. Configurar: locale pt_BR, usuario, hostname'
        Write-Status '  5. Validar boot do Linux antes de prosseguir'
        Write-Status ''
        Write-Status 'Apos boot: reconciliar dados preservados (FASE 8 PENDENTE):'
        Write-Status '  [ ] Backup externo verificavel + hashes + inventario'
        Write-Status '  [ ] Localizar K: NTFS por UUID/label no Linux; montar inicialmente read-only'
        Write-Status '  [ ] Resolver CENTRALDARK_ROOT sem presumir /root'
        Write-Status '  [ ] Reutilizar install.sh e restore canonicos para dados allowlisted'
        Write-Status '  [ ] Replay das receitas + comprovacao de arquivos/servicos'
        Write-Status '  [ ] Exposicao privada por padrao; publico so por configuracao posterior'
        Write-Status '  [ ] Verificar espaco restante antes de planejar qualquer expansao'
        Write-Status '  POST_BOOT_RECONCILIATION=UNKNOWN (nao executada)'
        Write-Status ''
        Write-Status 'Nenhuma acao destrutiva e executada por este instalador.'
    })

    $btnDualBoot.Add_Click({
        $script:txtOutput.Clear()
        & $updatePhase 'DUAL BOOT' 'GUIADO'
        Write-Status '======================================================'
        Write-Status '  DUAL BOOT - ETAPA GUIADA'
        Write-Status '======================================================'
        Write-Status ''
        Write-Status 'STATUS: PENDENTE - requer Linux instalado' 'PHASE'
        Write-Status ''
        Write-Status 'Pre-requisito: Fase INSTALAR LINUX concluida.'
        Write-Status ''
        Write-Status 'Passos (executar a partir do Linux instalado):'
        Write-Status '  1. Verificar particao EFI (mount /boot/efi)'
        Write-Status '  2. Instalar GRUB: grub-install --target=x86_64-efi'
        Write-Status '  3. Detectar Windows: os-prober'
        Write-Status '  4. Gerar config: grub-mkconfig -o /boot/grub/grub.cfg'
        Write-Status '  5. Reiniciar e testar menu GRUB (Linux + Windows)'
        Write-Status ''
        Write-Status 'Se GRUB nao detectar Windows automaticamente:'
        Write-Status '  - Verificar pacote os-prober instalado'
        Write-Status '  - GRUB_DISABLE_OS_PROBER=false em /etc/default/grub'
        Write-Status '  - Montar a particao EFI do Windows se necessario'
    })

    $btnHermes.Add_Click({
        $script:txtOutput.Clear()
        & $updatePhase 'HERMES CLI' 'GUIADO'
        Write-Status '======================================================'
        Write-Status '  HERMES CLI NO openKylin - ETAPA GUIADA'
        Write-Status '======================================================'
        Write-Status ''
        Write-Status 'STATUS: PENDENTE - Hermes CLI somente apos openKylin instalado' 'PHASE'
        Write-Status 'Previsao: instalar Hermes CLI DENTRO do Linux openKylin, NAO no Windows.'
        Write-Status 'Precondicao: Linux instalado, inicializado e com terminal/rede validos.'
        Write-Status 'Instalacao do Hermes CLI nao executada por este programa.'
        Write-Status 'A verificacao no Windows nao exige Hermes Desktop nem CLI.'
        Write-Status 'WSL e opcional e independente da instalacao do Hermes CLI no Linux.'
        Write-Status ''
        Write-Status '+----------------------------------------------------+'
        Write-Status '|  LIMITACAO TECNICA HONESTA                        |'
        Write-Status '+----------------------------------------------------+'
        Write-Status ''
        Write-Status 'O WSL2 executa um kernel Linux em VM leve (Hyper-V).'
        Write-Status 'Ele NAO pode usar a mesma instalacao Linux do disco'
        Write-Status 'como se fosse um unico sistema operacional.'
        Write-Status ''
        Write-Status 'O que o WSL PODE fazer:'
        Write-Status '  - wsl --mount \\.\PHYSICALDRIVEn --partition N --type ext4'
        Write-Status '    Monta a particao Linux como ponto de leitura dentro do WSL'
        Write-Status '    (NAO e o mesmo rootfs; e acesso ao disco, nao ao sistema)'
        Write-Status '  - Importar .tar do Linux como distro WSL separada (copia)'
        Write-Status '  - Compartilhar arquivos via particao NTFS visivel por ambos'
        Write-Status ''
        Write-Status 'O que o WSL NAO pode fazer:'
        Write-Status '  - Bootar o mesmo Linux instalado nativamente no disco'
        Write-Status '  - Usar os mesmos servicos/daemons do Linux fisico'
        Write-Status '  - Substituir o boot nativo para acessar hardware diretamente'
        Write-Status ''
        Write-Status 'Estrategia recomendada:'
        Write-Status '  1. Boot nativo para Linux completo (GPU, desktop, hardware)'
        Write-Status '  2. wsl --mount para acessar arquivos Linux do Windows'
        Write-Status '  3. Apos instalar openKylin, configurar Hermes CLI NO Linux'
        Write-Status '  4. Validar versao e execucao da CLI no proprio openKylin'
        Write-Status ''
        Write-Status 'NAO sera criada segunda capsula WSL openKylin.'
        Write-Status 'A distro WSL anterior foi removida pelo CHEFE.'
    })

    $btnVerify.Add_Click({
        try {
            $script:txtOutput.Clear()
            $script:lblStatusBar.Text = '  Verificando ambiente...'
            & $updatePhase 'VERIFICAR' 'EM CURSO'
            Write-Status 'Executando verificacao read-only do ambiente...'
            Write-Status ''
            $results = Invoke-ReadOnlyVerify -IsoPath $txtIso.Text
            foreach ($line in $results) {
                $script:txtOutput.AppendText("$line`r`n")
            }
            Write-Status ''
            $hasErrors = @($results | Where-Object { $_ -match '^\[ERRO\]' }).Count -gt 0
            $hasWarnings = @($results | Where-Object { $_ -match '^\[WARN\]' }).Count -gt 0
            if ($hasErrors) {
                Write-Status 'Verificacao FALHOU: existem erros de preflight. Nenhuma alteracao realizada.' 'ERROR'
                & $updatePhase 'VERIFICAR' 'PENDENTE'
                $script:lblStatusBar.Text = '  Verificacao falhou: corrigir erros'
            } elseif ($hasWarnings) {
                Write-Status 'Verificacao terminou com ALERTAS; o resultado nao e PASS completo.' 'WARN'
                & $updatePhase 'VERIFICAR' 'GUIADO'
                $script:lblStatusBar.Text = '  Verificacao com alertas'
            } else {
                Write-Status 'PASS read-only: ambiente consultado; nenhuma alteracao realizada.' 'OK'
                & $updatePhase 'VERIFICAR' 'CONCLUIDO'
                $script:lblStatusBar.Text = '  Verificacao concluida | Pasta: ' + $script:InstallerDir
            }
        } catch {
            Write-Status "Erro na verificacao: $($_.Exception.Message)" 'ERROR'
            & $updatePhase 'VERIFICAR' 'PENDENTE'
            $script:lblStatusBar.Text = '  Erro durante verificacao'
        }
    })

    $btnExport.Add_Click({
        $content = $script:txtOutput.Text
        if ([string]::IsNullOrWhiteSpace($content)) {
            Write-Status 'Nada para exportar. Execute uma acao primeiro.' 'WARN'
            return
        }
        $header  = "CENTRALDARK INSTALLER v3.0 - RELATORIO`r`n"
        $header += "Gerado em  : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`n"
        $header += "Admin      : $(if (Test-IsAdmin) {'SIM'} else {'NAO'})`r`n"
        $header += "Disco      : $($cmbDisk.SelectedItem)`r`n"
        $header += "ISO        : $($txtIso.Text)`r`n"
        $header += "Preservar  : $($chkPreserve.Checked)`r`n"
        $header += "=======================================================`r`n`r`n"
        Export-Report -Content ($header + $content)
    })

    $btnClose.Add_Click({ $form.Close() })

    & $updateButtons

    Write-Status 'CENTRALDARK INSTALLER v3.0 iniciado.' 'OK'
    if (-not $isAdmin) {
        Write-Status 'Executando sem privilegio de Administrador. Algumas consultas podem falhar.' 'WARN'
    }
    Write-Status 'PASS read-only nao instala Linux: passos 1-5 consultam; passos 6-8 sao SOMENTE GUIADOS.'
    Write-Status 'Siga os passos numerados: 1 ANALISAR, 2 PREPARAR, 3 VERIFICAR, 4 SHA256, 5 EXPORTAR.'
    Write-Status ''

    [void]$form.ShowDialog()
    $form.Dispose()
}

# -- Ponto de entrada --------------------------------------------------
Show-MainWindow
