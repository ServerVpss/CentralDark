// CENTRALDARK INSTALLER v3.0 — Launcher nativo Windows (sem console)
// Compilar com:
//   C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe /nologo /target:winexe /platform:anycpu /out:"CentralDark-Installer.exe" /r:System.Windows.Forms.dll "CentralDark-Installer-Launcher.cs"

using System;
using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("CentralDark Installer")]
[assembly: System.Reflection.AssemblyDescription("Launcher nativo para CentralDark Installer")]
[assembly: System.Reflection.AssemblyProduct("CentralDark Installer")]
[assembly: System.Reflection.AssemblyVersion("3.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("3.0.0.0")]

namespace CentralDark
{
    static class Launcher
    {
        private const string ScriptName = "CentralDark-Installer.ps1";
        private const string AppTitle   = "CENTRALDARK INSTALLER v3.0";
        private static readonly string MutexId = "Global\\CentralDark-Installer-SingleInstance";

        static bool IsAdmin()
        {
            try
            {
                var identity = WindowsIdentity.GetCurrent();
                var principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        [STAThread]
        static int Main()
        {
            bool createdNew;
            using (var mutex = new Mutex(true, MutexId, out createdNew))
            {
                if (!createdNew)
                {
                    MessageBox.Show(
                        "O CentralDark Installer ja esta em execucao.",
                        AppTitle,
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return 1;
                }

                if (!IsAdmin())
                {
                    var result = MessageBox.Show(
                        "O CentralDark Installer nao esta executando como Administrador.\n\n" +
                        "Sem elevacao, consultas de disco e particao podem falhar.\n\n" +
                        "Deseja reiniciar como Administrador?",
                        AppTitle,
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        try
                        {
                            var exe = System.Reflection.Assembly.GetExecutingAssembly().Location;
                            var psi = new ProcessStartInfo(exe) { Verb = "runas", UseShellExecute = true };
                            Process.Start(psi);
                            return 0;
                        }
                        catch (System.ComponentModel.Win32Exception)
                        {
                            // UAC cancelled by user — continue without elevation
                        }
                    }
                }

                try
                {
                    return RunInstaller();
                }
                catch (Exception ex)
                {
                    string errorLog = null;
                    try
                    {
                        string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                        string candidateLog = Path.Combine(baseDir,
                            "CentralDark-Error_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".txt");
                        File.WriteAllText(candidateLog, ex.ToString());
                        errorLog = candidateLog;
                    }
                    catch { }

                    string msg = "Erro ao iniciar o CentralDark Installer:\n\n" + ex.Message;
                    if (errorLog != null)
                        msg += "\n\nDetalhes salvos em:\n" + errorLog;

                    MessageBox.Show(msg, AppTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 2;
                }
            }
        }

        static int RunInstaller()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string scriptPath = Path.Combine(baseDir, ScriptName);

            if (!File.Exists(scriptPath))
            {
                MessageBox.Show(
                    "Script nao encontrado:\n" + scriptPath +
                    "\n\nO arquivo " + ScriptName + " deve estar na mesma pasta do executavel.",
                    AppTitle,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return 3;
            }

            string psExe = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.System),
                "WindowsPowerShell", "v1.0", "powershell.exe");

            if (!File.Exists(psExe))
            {
                psExe = "powershell.exe";
            }

            string arguments = string.Format(
                "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"{0}\"",
                scriptPath);

            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = psExe;
            psi.Arguments = arguments;
            psi.WorkingDirectory = baseDir;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            // O launcher nao possui console. Capturar erros sem abrir terminal.
            psi.RedirectStandardOutput = false;
            psi.RedirectStandardError = true;

            using (Process proc = Process.Start(psi))
            {
                if (proc == null)
                {
                    MessageBox.Show(
                        "Nao foi possivel iniciar o PowerShell.",
                        AppTitle,
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return 4;
                }

                // Somente stderr e redirecionado. Sem dois pipes, nao ha espera circular.
                string errorText = proc.StandardError.ReadToEnd();
                proc.WaitForExit();

                int exitCode = proc.ExitCode;
                if (exitCode != 0)
                {
                    string baseDir2 = AppDomain.CurrentDomain.BaseDirectory;
                    string errorLog = Path.Combine(baseDir2,
                        "CentralDark-Error_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt");

                    bool logSaved = false;
                    try
                    {
                        File.WriteAllText(errorLog,
                            "PowerShell exit code: " + exitCode + Environment.NewLine +
                            "Script: " + scriptPath + Environment.NewLine +
                            "Arguments: " + arguments + Environment.NewLine +
                            "Timestamp: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine +
                            "PowerShell stderr:" + Environment.NewLine + errorText);
                        logSaved = true;
                    }
                    catch { }

                    string failureMessage = "O instalador encerrou com codigo de erro: " + exitCode;
                    failureMessage += logSaved
                        ? "\n\nDetalhes salvos em:\n" + errorLog
                        : "\n\nNao foi possivel gravar o relatorio de erro.";
                    MessageBox.Show(
                        failureMessage,
                        AppTitle,
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }

                return exitCode;
            }
        }
    }
}
