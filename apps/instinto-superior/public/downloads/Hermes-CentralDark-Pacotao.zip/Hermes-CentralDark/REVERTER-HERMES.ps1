& "$PSScriptRoot\INSTALAR-HERMES.ps1" -Action Rollback
