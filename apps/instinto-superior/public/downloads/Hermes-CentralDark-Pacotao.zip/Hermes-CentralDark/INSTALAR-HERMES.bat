@echo off
setlocal
set "DEST=%USERPROFILE%\CentralDark\Hermes"
set "BACKUP=%USERPROFILE%\CentralDark\Hermes-backup"
if exist "%DEST%" (
  if exist "%BACKUP%" rmdir /S /Q "%BACKUP%"
  xcopy "%DEST%" "%BACKUP%\" /E /I /Y >nul
)
if not exist "%DEST%" mkdir "%DEST%"
xcopy "%~dp0assets" "%DEST%\assets\" /E /I /Y >nul
xcopy "%~dp0metadata" "%DEST%\metadata\" /E /I /Y >nul
copy /Y "%~dp0manifesto.json" "%DEST%\manifesto.json" >nul
echo Hermes instalado em %DEST%
echo Backup anterior em %BACKUP%
pause
