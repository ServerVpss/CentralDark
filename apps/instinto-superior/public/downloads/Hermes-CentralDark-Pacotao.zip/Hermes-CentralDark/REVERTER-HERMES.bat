@echo off
setlocal
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALAR-HERMES.ps1" -Action Rollback
if errorlevel 1 (
  echo Falha no rollback. Consulte a mensagem acima.
  pause
  exit /b 1
)
echo Hermes anterior restaurado.
pause
