param(
  [ValidateSet("Install", "Rollback")]
  [string]$Action = "Install"
)
$ErrorActionPreference = "Stop"
$source = Join-Path $PSScriptRoot "assets\instinto-superior"
$targets = @(
  (Join-Path $env:LOCALAPPDATA "hermes\pets\hermes-centraldark-instinto-superior"),
  (Join-Path $HOME ".codex\pets\hermes-centraldark-instinto-superior")
)
foreach ($dest in $targets) {
  $backup = "$dest.backup"
  if ($Action -eq "Rollback") {
    if (-not (Test-Path $backup)) { throw "Rollback indisponivel: $backup nao existe" }
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    Move-Item $backup $dest -Force
    Write-Host "ROLLBACK_OK=$dest"
    continue
  }

  New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
  if (Test-Path $dest) {
    if (Test-Path $backup) { Remove-Item $backup -Recurse -Force }
    Move-Item $dest $backup -Force
    Write-Host "BACKUP_OK=$backup"
  }
  try {
    New-Item -ItemType Directory -Force $dest | Out-Null
    Copy-Item (Join-Path $source "spritesheet.webp") $dest -Force
    Copy-Item (Join-Path $PSScriptRoot "metadata\instinto-superior.json") (Join-Path $dest "pet.json") -Force
    Write-Host "INSTALL_OK=$dest"
  } catch {
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    if (Test-Path $backup) { Move-Item $backup $dest -Force }
    throw
  }
}
