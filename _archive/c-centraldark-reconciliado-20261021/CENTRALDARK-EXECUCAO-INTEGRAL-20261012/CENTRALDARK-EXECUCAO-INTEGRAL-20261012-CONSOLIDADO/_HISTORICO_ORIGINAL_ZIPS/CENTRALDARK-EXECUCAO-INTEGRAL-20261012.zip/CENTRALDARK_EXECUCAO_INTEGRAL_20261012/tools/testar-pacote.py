#!/usr/bin/env python3
"""Testes offline da receita, nao testa VPS de outro ambiente."""
import pathlib,hashlib,json,subprocess,sys
BASE=pathlib.Path(__file__).resolve().parent.parent
failures=[]
def check(name,condition):
 print(('🟢 PASS' if condition else '🔴 FAIL')+' '+name)
 if not condition:failures.append(name)
proof=json.loads((BASE/'EVIDENCIAS/RECEIPTS-20261012.json').read_text())
routes=json.loads((BASE/'EVIDENCIAS/ROTAS-20261012.json').read_text())
check('schema',proof['schema']=='centraldark.execucao-integral.v1')
check('intent',proof['mission_id']=='CENTRALDARK_DUAS_FRENTES_20261012')
check('2 fronts',set(('mcp_dispatcher','reconciler')).issubset(proof['sources']))
check('both original source blobs 40hex',all(len(proof['sources'][x]['blob_sha'])==40 for x in ('mcp_dispatcher','reconciler')))
check('13 documented routes',len(routes['routes'])==13)
check('external policies not bypassed',routes['laws']['clientPolicyGateIsNotBypassable'])
check('pulse unproven',proof['measured']['pulse_live']['status']=='UNKNOWN')
check('hakai not executed',proof['measured']['hakai']['status']=='NOT_EXECUTED')
check('both historical scans partial',all(proof['measured'][x]['partial'] for x in ('scan_1','scan_2')))
check('backup original hash',proof['sources']['reconciler']['sha256_backup_old'].startswith('4792fab2'))
script=BASE/'executar-tudo.sh'
check('bash syntax',subprocess.run(['bash','-n',str(script)],capture_output=True).returncode==0)
script2=BASE/'tools/exportar-codigo-fixado.sh'
check('exporter bash syntax',subprocess.run(['bash','-n',str(script2)],capture_output=True).returncode==0)
raw=script.read_text()
check('no root reset',('git reset --hard' not in raw and 'git clean -fdx' not in raw and 'push --force' not in raw))
check('scan uses owner existing', '"$MAIN" --scan' in raw)
check('hakai read only', 'HAKAI=BLOCKED' in raw and '--hakai-check)' in raw)
check('sha gated apply', 'UNEXPECTED_SHA_NEVER_OVERWRITE' in raw and 'BACKUP_READBACK_FAIL' in raw)
check('MCP owner deployment guarded', '--dry-run' in raw and 'MCP_RUNTIME_NOT_PROMOTED' in raw)
for f in (BASE/'EVIDENCIAS').glob('*.json'):
 json.loads(f.read_text())
check('JSON examples valid',True)
print('TESTS_FAILED='+str(len(failures)))
sys.exit(1 if failures else 0)
