#!/usr/bin/env python3
"""Read-only preflight CentralDark. Stdlib apenas; nao cria recibos na VPS."""
import argparse, json, os, hashlib, subprocess, pathlib, sys, time, shutil
from datetime import datetime, timezone
BASE=pathlib.Path(__file__).resolve().parent.parent
PROOF=json.loads((BASE/'EVIDENCIAS/RECEIPTS-20261012.json').read_text(encoding='utf-8'))
p=argparse.ArgumentParser()
p.add_argument('--repo',default=os.environ.get('CENTRALDARK_REPO','/root/CentralDark'))
p.add_argument('--state',default=os.environ.get('CENTRALDARK_INVENTORY_STATE','/var/lib/centraldark/inventory-reconcile'))
p.add_argument('--json',action='store_true')
a=p.parse_args()
repo=pathlib.Path(a.repo);state=pathlib.Path(a.state);checks=[]
def add(name,status,detail,critical=False):
 checks.append({'test':name,'status':status,'detail':str(detail)[:500],'critical':critical})
def call(*args,timeout=9):
 try:
  p=subprocess.run(args,cwd=repo,capture_output=True,text=True,timeout=timeout,check=False)
  return p.returncode,p.stdout.strip(),p.stderr.strip()
 except (OSError,subprocess.TimeoutExpired) as exc:return 124,'',str(exc)
add('repo_git','PASS' if (repo/'.git').exists() else 'BLOCKED',repo,True)
if (repo/'.git').exists():
 code,sha,err=call('git','rev-parse','HEAD');add('vps_head','PASS' if code==0 else 'UNKNOWN',sha or err)
 code,sha,err=call('git','rev-parse','origin/main');add('cached_main','PASS' if code==0 else 'UNKNOWN',sha or err)
 code,status,err=call('git','status','--porcelain','--untracked-files=no');add('tracked_dirty','DIRTY' if code==0 and status else ('CLEAN' if code==0 else 'UNKNOWN'),len(status.splitlines()) if code==0 else err)
 for key in ('mcp_dispatcher','reconciler'):
  item=PROOF['sources'][key]
  code,sha,err=call('git','rev-parse',f"origin/main:{item['path']}")
  want=item['blob_sha'];add('main_blob_'+key,'PASS' if sha==want else ('DRIFT' if code==0 else 'UNKNOWN'),f'expected={want}; current={sha or err}',True)
  code,out,err=call('git','cat-file','-e',item.get('creation_commit',item.get('final_patch_commit'))+'^{commit}')
  add('pinned_commit_'+key,'PASS' if code==0 else 'UNKNOWN',item.get('creation_commit',item.get('final_patch_commit')))
 current=repo/PROOF['sources']['reconciler']['path']
 if current.is_file():
  sha=hashlib.sha256(current.read_bytes()).hexdigest();want=PROOF['sources']['reconciler']['sha256_running']
  add('vps_reconciler_sha','PASS' if sha==want else 'DRIFT',f'current={sha}; expected={want}',True)
  code,out,err=call('bash','-n',str(current));add('reconciler_syntax','PASS' if code==0 else 'FAIL',err or 'bash -n',True)
  code,out,err=call('bash',str(current),'--pulse','--plan',timeout=15)
  add('pulse_readonly_plan','PASS' if code==0 and 'PULSE_PLAN=READ_ONLY' in out else 'FAIL',out or err,True)
 else:add('vps_reconciler_file','BLOCKED','Arquivo não existe na VPS',True)
 mcpfile=repo/'apps/modulos/mcp/src/tools/core/mcp-admin.js'
 if mcpfile.is_file():
  data=mcpfile.read_text(encoding='utf8',errors='replace')
  add('runtime_checkout_mcp_diagnostic_marker','SOURCE_VISIBLE' if 'diagnoseMcpBlock' in data else 'UNKNOWN','Working tree, nao prova do processo ativo')
  if shutil.which('node'):
   code,out,err=call('node','--check',str(mcpfile),timeout=20)
   add('mcp_checkout_node_check','PASS' if code==0 else 'FAIL',err or 'node --check')
 else:add('mcp_code_file','UNKNOWN','Dispatcher local não encontrado')
 receipt=state/'centraldark-inventory-reconcile.json'
 if receipt.is_file():
  try:
   data=json.loads(receipt.read_text(encoding='utf8'))
   add('json_canonical','PASS','json válido, bytes='+str(receipt.stat().st_size),True)
   dup=data.get('duplicates') or {}
   add('scanner_coverage','PARTIAL' if dup.get('partial') else 'UNKNOWN' if not dup else 'PASS',json.dumps({'skipped':dup.get('skipped'),'scripts':dup.get('scanned_script_files')},ensure_ascii=False))
   add('pulse_live_parity','UNKNOWN',str(data.get('pulse')))
  except (OSError,ValueError,TypeError) as exc:add('json_canonical','FAIL',str(exc),True)
 else:add('json_canonical','UNKNOWN','recibo canônico não materializado',True)
 for old in ('latest.json','delta.json'):
  add('legacy_receipt_'+old,'PRESENT_NEEDS_RECONCILIATION' if (state/old).exists() else 'NOT_ACTIVE','não apagar histórico; preservar em backup')
 backup=state/'backups/20261012T225707Z/centraldark-inventory-reconcile.sh'
 if backup.is_file():
  s=hashlib.sha256(backup.read_bytes()).hexdigest()
  add('original_backup','PASS' if s==PROOF['sources']['reconciler']['sha256_backup_old'] else 'DRIFT',s,True)
 else:add('original_backup','UNKNOWN','backup não localizado',True)
 add('mcp_runtime_deploy','UNKNOWN','Commit válido != runtime atualizado')
 add('hakai_allowed','BLOCKED','Pulso real e todos os consumidores ainda não provados')
statuses=[x['status'] for x in checks]
result={'schema':'centraldark.replay.check.v1','at':datetime.now(timezone.utc).isoformat(),'checks':checks,'fatal':any(x['critical'] and x['status'] in {'FAIL','BLOCKED','DRIFT'} for x in checks)}
if a.json:print(json.dumps(result,ensure_ascii=False,indent=2))
else:
 for item in checks:
  sym='🟢' if item['status']=='PASS' else ('🔴' if item['status'] in ('FAIL','BLOCKED','DRIFT') else '🟡')
  print(f"{sym} [{item['status']}] {item['test']}: {item['detail']}")
 print('⚖️ GLOBAL_PASS=FALSE se runtime MCP ou pulso real UNKNOWN; audited_count='+str(len(checks)))
sys.exit(2 if result['fatal'] else 0)
