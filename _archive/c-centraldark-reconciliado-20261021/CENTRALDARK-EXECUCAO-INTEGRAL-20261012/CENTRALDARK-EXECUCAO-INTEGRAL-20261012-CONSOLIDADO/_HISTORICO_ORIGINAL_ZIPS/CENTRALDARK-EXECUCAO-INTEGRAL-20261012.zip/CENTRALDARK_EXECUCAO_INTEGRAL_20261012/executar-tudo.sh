#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
ROOT="${CENTRALDARK_REPO:-/root/CentralDark}"
STATE="${CENTRALDARK_INVENTORY_STATE:-/var/lib/centraldark/inventory-reconcile}"
MAIN_REL="scripts/centraldark-inventory-reconcile.sh"
MAIN="$ROOT/$MAIN_REL"
RECEIPT="$STATE/centraldark-inventory-reconcile.json"
BACKUP_ROOT="$STATE/backups"
EXPECTED_NEW="b56706f65fd045acc60dc88d11643362faded88ae9f0a504a7ec17bf2a906830"
EXPECTED_ORIGINAL="4792fab2b553537219fe43afe06cb8a9745f02ad4d897d17870575218d75f902"
PIN="9277a9ff41c7b341411fe6465186231554116904"
BLOB="4a70ed98f37990e0f099dfbed9b1eb419bc53e31"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:---audit}"
log(){ printf '%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }
fail(){ log "🔴 BLOCKED: $*";exit 2; }
need(){ command -v "$1" >/dev/null || fail "FERRAMENTA_AUSENTE=$1"; }
sha(){ sha256sum "$1" | awk '{print $1}'; }
gates(){
 need git; need bash; need python3; need sha256sum
 [[ -d "$ROOT/.git" ]] || fail "CHECKOUT_INEXISTENTE=$ROOT"
 log "👑🪬 GOAL=ONE_INTENT TWO_OWNERS FRONT1_MCP FRONT2_RECONCILER"
 log "🔗 REPO=$ROOT MODE=$MODE"
 log "🏛️ VPS_HEAD=$(git -C "$ROOT" rev-parse HEAD)"
 log "🏛️ MAIN_CACHED=$(git -C "$ROOT" rev-parse origin/main 2>/dev/null || echo UNKNOWN)"
 log "🛡️ NO_RESET NO_CLEAN NO_FORCE_PUSH NO_SECRET_SEARCH"
}
case "$MODE" in
 --audit)
  gates
  log '🟢 FRENTE_1: consulta de origem, sem declarar runtime implantado'
  # Exit 2 pode sinalizar drift/UNKNOWN; auditoria ainda exibe diagnóstico completo.
  python3 "$HERE/tools/verificar-integridade.py" --repo "$ROOT" --state "$STATE" || true
  log '🟡 MCP_RUNTIME_NEW_CODE=UNKNOWN; MICRODEPLOY_FILESET_NOT_APPROVED (ultimo ensaio)'
  log '🟢 FRENTE_2: inventário/plan/backup verificados sem HAKAI'
  log '🟡 PULSE_LIVE=UNKNOWN; SCAN_COMPLETE=UNKNOWN; HAKAI=NOT_EXECUTED'
  log '🧭 NEXT_CURSOR=MCP_OWNER_RUNTIME + PULSE_LIVE_PARITY + CALLER_MAP'
  ;;
 --scan)
  gates
  [[ -f "$MAIN" ]] || fail 'RECONCILIADOR_AUSENTE'
  [[ "$(sha "$MAIN")" == "$EXPECTED_NEW" ]] || fail 'SCRIPT_DRIFT_PROTEGIDO'
  bash -n "$MAIN" || fail 'BASH_SYNTAX_FAIL'
  log '🔎 SCAN_START=script_existente; até limite interno do scanner'
  "$MAIN" --scan
  python3 -m json.tool "$RECEIPT" >/dev/null || fail 'RECEIPT_INVALID'
  python3 - "$RECEIPT" <<'PY'
import json,sys
v=json.load(open(sys.argv[1]));d=v.get('duplicates') or {}
print('🧾 RECEIPT_VALID=true; PARTIAL='+str(d.get('partial')).upper()+'; FILES='+str(d.get('scanned_script_files'))+'; SAME_BYTES='+str(d.get('exact_bytes_count')))
if d.get('partial'):print('🟡 GLOBAL_SCRIPT_SCAN_NOT_EXHAUSTIVE=true')
PY
  log '🛡️ SCAN_NAO_DELETA=TRUE'
  ;;
 --pulse-plan)
  gates
  [[ -f "$MAIN" ]] || fail 'RECONCILIADOR_AUSENTE'
  bash -n "$MAIN" || fail 'BASH_SYNTAX_FAIL'
  "$MAIN" --pulse --plan
  log '🛡️ PLAN_NAO_EQUIVALE_A_PULSE_RUNTIME_PASS'
  ;;
 --apply-reconciler)
  gates
  [[ -f "$MAIN" ]] || fail 'RECONCILIADOR_ANTIGO_AUSENTE'
  current="$(sha "$MAIN")"
  if [[ "$current" == "$EXPECTED_NEW" ]]; then log '🟢 NOOP_RECONCILER_ALREADY_INSTALLED';exit 0;fi
  [[ "$current" == "$EXPECTED_ORIGINAL" ]] || fail "UNEXPECTED_SHA_NEVER_OVERWRITE=$current"
  [[ "$(git -C "$ROOT" rev-parse "$PIN:$MAIN_REL")" == "$BLOB" ]] || fail 'PIN_BLOB_MISMATCH'
  mkdir -p "$BACKUP_ROOT"
  checkpoint="$BACKUP_ROOT/$(date -u +%Y%m%dT%H%M%SZ)-replay"
  mkdir -m 700 "$checkpoint"
  cp -p "$MAIN" "$checkpoint/centraldark-inventory-reconcile.sh"
  [[ "$(sha "$checkpoint/centraldark-inventory-reconcile.sh")" == "$current" ]] || fail 'BACKUP_READBACK_FAIL'
  tmp="$MAIN.replay-stage-$$"
  rollback(){ code=$?;trap - EXIT; if [[ $code -ne 0 ]];then
    if [[ -f "$checkpoint/centraldark-inventory-reconcile.sh" ]];then
      cp -p "$checkpoint/centraldark-inventory-reconcile.sh" "$MAIN"
      log "🔴 ROLLBACK_RESTORED=$MAIN"
    fi
   fi;rm -f -- "$tmp";exit "$code"; }
  trap rollback EXIT
  git -C "$ROOT" show "$PIN:$MAIN_REL" > "$tmp"
  [[ "$(sha "$tmp")" == "$EXPECTED_NEW" ]] || fail 'PIN_SHA256_MISMATCH'
  bash -n "$tmp" || fail 'BASH_N_FAIL'
  chmod --reference="$MAIN" "$tmp";mv -- "$tmp" "$MAIN"
  bash -n "$MAIN" || fail 'AFTER_INSTALL_BASH_N_FAIL'
  [[ "$(sha "$MAIN")" == "$EXPECTED_NEW" ]] || fail 'AFTER_INSTALL_SHA_MISMATCH'
  "$MAIN" --pulse --plan || fail 'PULSE_PLAN_FAIL_ROLLBACK'
  trap - EXIT
  log "🟢 INSTALLED_READBACK=$(sha "$MAIN") BACKUP=$checkpoint"
  log '🟡 PULSE_LIVE_NAO_TESTADO HAKAI_PROIBIDO'
  ;;
 --hakai-check)
  gates
  log '🧿 HAKAI_GUARD=NO_DELETE (somente verifica chamadores conhecidos)'
  if [[ -e "$ROOT/scripts/vps/main-pulse-reconciler.sh" ]];then
   log '🟡 LEGACY_PULSE_EXISTS=true'
  else log '🟡 LEGACY_PULSE_EXISTS=false (origem UNKNOWN)';fi
  for dir in "$ROOT/scripts" "$ROOT/.github" "$ROOT/apps/modulos/HERMES-CORE" /etc/systemd/system /etc/cron.d;do
   if [[ -d "$dir" ]];then
    grep -R -l -F --exclude-dir=.git --exclude-dir=node_modules 'main-pulse-reconciler.sh' "$dir" 2>/dev/null || true
   fi
  done
  if command -v systemctl >/dev/null;then
   systemctl list-timers --all --no-pager 2>/dev/null | grep -i 'main.pulse\|centraldark' || true
  fi
  if command -v pgrep >/dev/null;then
   pgrep -af 'main-pulse-reconciler.sh' || true
  fi
  log '🔴 HAKAI=BLOCKED: pulse live parity & all users crontabs not proved'
  ;;
 --mcp-rebuilder)
  gates
  log '🔌 MCP_REBUILDER: medir owner existente, sem criar core nem burlar o gate'
  if [[ -f "$ROOT/apps/modulos/mcp/src/tools/core/mcp-admin.js" ]];then
   grep -n -m 2 'MCP_BLOCK_RECONCILIATION\|diagnoseMcpBlock' "$ROOT/apps/modulos/mcp/src/tools/core/mcp-admin.js" || true
  fi
  if [[ -x "$ROOT/scripts/vps/main-pinned-microdeploy.sh" ]];then
   log '🧪 MICRODEPLOY_PREFLIGHT=EXISTING_OWNER_ONLY'
   "$ROOT/scripts/vps/main-pinned-microdeploy.sh" --owner mcp --source "$PIN" --file apps/modulos/mcp/src/tools/core/mcp-admin.js --dry-run || log '🟡 GATE_REFUSED=EXPECTED_IF_FILESET_NOT_APPROVED'
  fi
  log '🟡 MCP_RUNTIME_NOT_PROMOTED_BY_THIS_MODE'
  ;;
 --help|-h)
  cat <<'USO'
Uso: bash executar-tudo.sh [--audit|--scan|--pulse-plan|--apply-reconciler|--hakai-check|--mcp-rebuilder]
--audit (padrão): somente leitura, conserva dirty state
--scan: executa o reconciliador existente (atualiza apenas seu JSON de recibo)
--pulse-plan: read-only, NÃO executa pulse real
--apply-reconciler: idempotente, valida SHA e backup, rollback em falha
--hakai-check: só leitura, legado não é apagado
--mcp-rebuilder: valida owner e microdeploy dry-run, NÃO desbloqueia proteção
USO
  ;;
 *)fail "MODO_DESCONHECIDO=$MODE";;
esac
