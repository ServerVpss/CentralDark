# 👑🪬 CENTRALDARK — REPLAY FIEL DAS DUAS FRENTES

**MISSÃO:** `CENTRALDARK_DUAS_FRENTES_20261012` · **INTENÇÃO:** uma intenção, dois owners existentes, execução verificável e sem arquiteturas paralelas.

**Autoridade:** `ServerVpss/CentralDark@main` para código; **VPS** para runtime; **Casa/SEGREDO** para a ponte já autorizada. Documento não é execução, commit não é deploy, rota documentada não é rota ativa, UNKNOWN não é PASS.

## Começar sem micro-passos

Na VPS (checkout existente, de preferência `/root/CentralDark`):

```bash
unzip CENTRALDARK-EXECUCAO-INTEGRAL-20261012.zip -d /tmp/centraldark-replay
cd /tmp/centraldark-replay/CENTRALDARK_EXECUCAO_INTEGRAL_20261012
bash ./executar-tudo.sh --audit
```

Na Casa Windows PowerShell 7, com o alias OpenSSH **já existente** `Segredo-VPS`:

```powershell
pwsh -NoProfile -File .\executar-casa.ps1 -ZipPath .\CENTRALDARK-EXECUCAO-INTEGRAL-20261012.zip -Mode audit
```

Para executar a mesma varredura que foi medida e atualizar **somente o JSON canônico já existente** (pode levar 30–60 segundos):

```bash
bash ./executar-tudo.sh --scan
```

Para reaplicar **somente** o reconciliador da `main` caso a cópia atual seja exatamente a versão original conhecida (backup antes, readback SHA, rollback em erro):

```bash
bash ./executar-tudo.sh --apply-reconciler
```

Se a versão atual já coincide com a `main` fixada, retorna NOOP. Se divergir inesperadamente, **BLOCKED**. Não aplica código mais novo por engano. `--hakai-check` só inspeciona dependências; **não deleta** o pulso legado.

## O que está no pacote

- `executar-tudo.sh`: orquestrador de uma intenção; preflight, duas frentes, auditoria, scan opcional, aplicação idempotente, rollback local, HAKAI apenas inspecionado.
- `executar-casa.ps1`: reutiliza SSH `Segredo-VPS` com verificação de host key, sem imprimir segredo, e executa o pacote na VPS por caminho temporário.
- `tools/verificar-integridade.py`: mede provas e fronteiras, SHA dos arquivos, main, sintaxe, JSON, parcialidade, backups e chamados.
- `tools/exportar-codigo-fixado.sh`: materializa **o código integral** dos owners originais diretamente dos objetos Git identificados por commit; nenhum código é reconstruído por adivinhação.
- `tools/testar-pacote.py`: testes offline de integridade/contrato do pacote.
- `EVIDENCIAS/RECEIPTS-20261012.json`: fatos medidos, limites e caminhos existentes, sem segredos.
- `EVIDENCIAS/ROTAS-20261012.json`: catálogo de rotas documentadas e provas por esta sessão.
- `EVIDENCIAS/EXECUCAO-PASSO-A-PASSO.md`: fluxo fiel do painel fornecido, resultado real versus intenção e as correções realizadas.
- `EVIDENCIAS/10-MELHORIAS-MCP.md`: aprendizagem consolidada e fronteira externa de segurança.
- `EVIDENCIAS/PLANO-HAKAI-E-REBUILDER.md`: lacunas e gates necessários antes de aposentar o pulso ou promover o MCP.

## Fonte integral dos códigos

Os arquivos do MCP, guard, testes, pulso e reconciliador **já existem no Git da `main`**. Para evitar carregar cópias divergentes/obsoletas no sistema, o comando `tools/exportar-codigo-fixado.sh DESTINO` recupera **cada byte** de commits fixados, compara os blobs e exporta à pasta solicitada. O ZIP é uma *receita reexecutável e conferível*, não um novo runtime nem outro motor.

Se os commits fixados não estiverem materializados no checkout, a exportação falha explicitamente. Recuperar com `git fetch origin main` é operação separada e consciente; nunca `git reset --hard`, `git clean`, `git push --force` ou `git pull` às cegas.

## 2 frentes, uma intenção

**F1 (MCP + Rebuilder):** diagnóstico `MCP_BLOCK_RECONCILIATION`, resposta `diagnostico`, lei `clientSafetyGateIsOutsideMcp`; alteração na main **PROVADA COMO CÓDIGO**, runtime novo ainda **UNKNOWN**, pois o microdeploy original recusou o fileset. O Rebuilder deve reutilizar owner comprovado; **não foi encontrado um owner 'rebuilder' no levantamento limitado a `apps/modulos/mcp` e `scripts`**, então não presumir instalado.

**F2 (reconciliador):** `.sh` canônico copiado com readback SHA correto; `--pulse --plan` read-only comprovado; `--scan` teve `exitCode=0`, JSON único ativo; **varredura parcial**; `--pulse` real **não comprovado**; script legado permanece.

## Proteções fixas

- `--audit` **não altera** arquivo de produção; lê repo/JSON e testa sintaxe (sem fetch automático).
- `--scan` roda ferramenta existente e modifica apenas seu recibo canônico, não deleta duplicatas.
- `--apply-reconciler` só atualiza se a versão atual tem SHA original exato; cria backup com timestamp e reverte no erro; não altera MCP.
- `--hakai-check` é somente leitura. HAKAI automático **proibido** até prova da execução real do pulso e de ausência de consumidores. Candidatos heurísticos nunca são deleções automáticas.
- Nenhuma variável secreta, token, chave, IP ou credencial é incluída.
- Toda falha com status `BLOCKED` mantém histórico de prova e sugere o próximo cursor; não é promovida a verde.
