<#
.SYNOPSIS
Replay CentralDark via rota JÁ conhecida: SEGREDO Windows -> OpenSSH alias Segredo-VPS -> VPS.
Não configura serviços, não instala dependências, não copia credenciais.
#>
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][string]$ZipPath,
 [ValidateSet('audit','scan','pulse-plan','apply-reconciler','hakai-check','mcp-rebuilder')][string]$Mode='audit',
 [string]$Alias='Segredo-VPS'
)
$ErrorActionPreference='Stop'
$zip=(Resolve-Path -LiteralPath $ZipPath).Path
if(-not (Get-Command ssh -ErrorAction SilentlyContinue)){throw 'SSH_NAO_DISPONIVEL_NO_WINDOWS'}
if(-not (Get-Command scp -ErrorAction SilentlyContinue)){throw 'SCP_NAO_DISPONIVEL_NO_WINDOWS'}
if($Alias -ne 'Segredo-VPS'){throw 'ALIASES_NAO_MEDIDOS_BLOQUEADOS'}
$opts=@('-o','BatchMode=yes','-o','ConnectTimeout=8','-o','StrictHostKeyChecking=yes','-o','IdentitiesOnly=yes')
$tag='centraldark-replay-'+[guid]::NewGuid().ToString('N').Substring(0,12)
$remoteZip='/tmp/'+$tag+'.zip'
$remoteDir='/tmp/'+$tag
Write-Host ('🪬 [CASA] MODO='+$Mode+' DESTINO='+$Alias+' (alias preexistente)')
& ssh @opts $Alias 'printf SSH_ROUTE_PASS' ; if($LASTEXITCODE -ne 0){throw 'SSH_ROUTE_BLOCKED'}
& scp @opts $zip "${Alias}:$remoteZip"; if($LASTEXITCODE -ne 0){throw 'SCP_FAILED'}
$cmd="set -Eeuo pipefail; mkdir -p '$remoteDir'; unzip -q '$remoteZip' -d '$remoteDir'; bash '$remoteDir/CENTRALDARK_EXECUCAO_INTEGRAL_20261012/executar-tudo.sh' '--$Mode'"
try { & ssh @opts $Alias $cmd; if($LASTEXITCODE -ne 0){throw ('REMOTE_EXIT='+$LASTEXITCODE)} }
finally {
 # Limpeza SOMENTE da pasta temporária gerada pelo pacote, jamais repo/VPS/root.
 & ssh @opts $Alias "rm -f '$remoteZip'; rm -r '$remoteDir'" | Out-Null
}
