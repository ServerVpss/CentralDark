#!/usr/bin/env python3
"""Testes offline da receita, nao testa VPS de outro ambiente."""
import pathlib,hashlib,json,subprocess,sys
BASE=pathlib.Path(__file__).resolve().parent.parent
failures=[]
def check(name,condition):
 print(('🟢 PASS' if condition else '🔴 FAIL')+' '+name)
 if not condition:failures.append(name)
proof=json.loads((BASE/'EVIDENCIAS/RECEIPTS-20261012.json').read_text())
routes=json.loads((BASE/'EVIDENCIAS/ROTAS-20261012.json').read_text())
check('schema',proof['schema']=='centraldark.execucao-integral.v1')
check('intent',proof['mission_id']=='CENTRALDARK_DUAS_FRENTES_20261012')
check('2 fronts',set(('mcp_dispatcher','reconciler')).issubset(proof['sources']))
check('both original source blobs 40hex',all(len(proof['sources'][x]['blob_sha'])==40 for x in ('mcp_dispatcher','reconciler')))
check('13 documented routes',len(routes['routes'])==13)
check('external policies not bypassed',routes['laws']['clientPolicyGateIsNotBypassable'])
check('pulse unproven',proof['measured']['pulse_live']['status']=='UNKNOWN')
check('hakai not executed',proof['measured']['hakai']['status']=='NOT_EXECUTED')
check('both historical scans partial',all(proof['measured'][x]['partial'] for x in ('scan_1','scan_2')))
check('backup original hash',proof['sources']['reconciler']['sha256_backup_old'].startswith('4792fab2'))
script=BASE/'executar-tudo.sh'
check('bash syntax',subprocess.run(['bash','-n',str(script)],capture_output=True).returncode==0)
script2=BASE/'tools/exportar-codigo-fixado.sh'
check('exporter bash syntax',subprocess.run(['bash','-n',str(script2)],capture_output=True).returncode==0)
raw=script.read_text()
check('no root reset',('git reset --hard' not in raw and 'git clean -fdx' not in raw and 'push --force' not in raw))
check('scan uses owner existing', '"$MAIN" --scan' in raw)
check('hakai read only', 'HAKAI=BLOCKED' in raw and '--hakai-check)' in raw)
check('sha gated apply', 'UNEXPECTED_SHA_NEVER_OVERWRITE' in raw and 'BACKUP_READBACK_FAIL' in raw)
check('MCP owner deployment guarded', '--dry-run' in raw and 'MCP_RUNTIME_NOT_PROMOTED' in raw)
for f in (BASE/'EVIDENCIAS').glob('*.json'):
 json.loads(f.read_text())
check('JSON examples valid',True)
print('TESTS_FAILED_V1='+str(len(failures)))

# v2: tests on the SAME files and an isolated tmp receipt. Never touch a VPS.
import tempfile
with tempfile.TemporaryDirectory(prefix='centraldark-replay-test-') as d:
  tmp=pathlib.Path(d)
  o=tmp/'orig.txt';f=tmp/'derived.txt'
  original=b'head:123\r\nline2:ABC\n'
  o.write_bytes(original);f.write_bytes(original+b'PLUS: NEW LEARNING\n')
  helper=BASE/'tools/verificar-integridade.py'
  def invoke(*args):
    return subprocess.run([sys.executable,str(helper),*args],capture_output=True,text=True,timeout=10)
  t=invoke('--compare-original',str(o),str(f),'--json')
  check('PAPAGAIO append-only PASS',t.returncode==0 and json.loads(t.stdout)['original_preserved_byte_for_byte'])
  f.write_bytes(original[:-3]+b'NEW')
  t=invoke('--compare-original',str(o),str(f),'--json')
  check('PAPAGAIO rewrite FAIL',t.returncode==3 and not json.loads(t.stdout)['original_preserved_byte_for_byte'])
  f.write_bytes(original[:5])
  t=invoke('--compare-original',str(o),str(f),'--json')
  check('PAPAGAIO truncate FAIL',t.returncode==3)
  repo=tmp/'fake-repo'; repo.mkdir()
  (repo/'scripts').mkdir()
  (repo/'scripts/centraldark-inventory-reconcile.sh').write_text('#!/usr/bin/env bash\necho "TEST"\n')
  state=tmp/'state';state.mkdir()
  receipt=state/'centraldark-inventory-reconcile.json'
  receipt.write_text(json.dumps({'schema':'centraldark.inventory.existing',
    'pulse':{'result':'UNKNOWN'},'duplicates':{'partial':True,'scanned_script_files':4224},
    'delta':{'changed':False},'user_owned_field':{'do_not_remove':True}}))
  t=invoke('--repo',str(repo),'--state',str(state),'--record-event','INTENT','PASS','ONLY_SCOPE_INTENT','--next-cursor','RECOVER')
  check('state INTENT persisted',t.returncode==0 and 'REPLAY_EVENT=INTENT' in t.stdout)
  t=invoke('--repo',str(repo),'--state',str(state),'--record-event','VERIFY','PARTIAL','SCAN_PARTIAL_REAL','--next-cursor','SCAN_COVERAGE')
  check('state VERIFY partial persisted',t.returncode==0)
  t=invoke('--repo',str(repo),'--state',str(state),'--record-event','HALT','BLOCKED','MCP_RUNTIME_UNKNOWN','--next-cursor','MCP_RUNTIME')
  check('state HALT blocked persisted',t.returncode==0)
  obj=json.loads(receipt.read_text())
  check('single canonical JSON',len(list(state.glob('*.json')))==1)
  check('no original JSON fields lost',obj.get('user_owned_field')=={'do_not_remove':True} and obj.get('delta')=={'changed':False} and obj.get('duplicates',{}).get('partial'))
  check('all checkpoint events preserved',len(obj.get('replay',{}).get('events',[]))==3 and obj['replay']['events'][0]['state']=='INTENT')
  check('global stays blocked',obj['replay']['global_pass'] is False and obj['replay']['next_cursor']=='MCP_RUNTIME')
  t=invoke('--repo',str(repo),'--state',str(state),'--read-replay','--json')
  check('recovery readback real',t.returncode==0 and json.loads(t.stdout)['event_count']==3 and json.loads(t.stdout)['status']=='BLOCKED')
  t=invoke('--repo',str(repo),'--state',str(state),'--record-event','UNTRUSTED','PASS','NO')
  check('invalid transition refused',t.returncode==2 and len(json.loads(receipt.read_text())['replay']['events'])==3)

shell=script.read_text()
check('state transitions documented',all(x in shell for x in ('--replay','--resume','replay_event','REPAIR','DIAGNOSE','HALT','SCANNER_DROPS_REPLAY_EVENTS')))
check('script bounded no HAkaI destructive', 'HAKAI=BLOCKED' in shell and 'main-pulse-reconciler.sh' in shell and 'rm -rf' not in shell)
check('one JSON active', 'centraldark-inventory-reconcile.json' in shell and '"$MAIN" --scan' in shell)
check('core pinned new owner', 'eaab55ffdf6cd928947a2967b8fd449c89bf7910' in shell and 'b56706f65fd045acc60dc88d11643362faded88ae9f0a504a7ec17bf2a906830' in shell)
check('Win route supports local PAPAGAIO compare',"'papagaio-check'" in (BASE/'executar-casa.ps1').read_text() and 'REWRITE_NOT_APPEND_ONLY' in (BASE/'executar-casa.ps1').read_text())
print('TESTS_FAILED_AFTER_V2='+str(len(failures)))
sys.exit(1 if failures else 0)
